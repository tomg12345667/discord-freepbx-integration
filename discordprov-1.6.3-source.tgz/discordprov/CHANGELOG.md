# Changelog

## 1.6.3
- **Important fix:** extension settings (including PJSIP extensions) live in FreePBX's `sip` table; the `pjsip` table is for trunks. The module wrote the generated password and max-contacts to `pjsip`, so passwords were never saved and a stray trunk row appeared. Everything now uses `sip`.
- The stray-row cleanup now finds `pjsip` ids that hold only a `max_contacts` row (never real trunks) and removes just those.
- Extension ids already used in `users`, `sip` or `pjsip` are never offered as free.

## 1.6.2
- Provisioning now verifies the PJSIP endpoint (its secret) was really written before returning credentials; otherwise it rolls back, removes partial rows and logs the reason.
- Follow-up to the 1.5.0 max-contacts bug, which could leave a lone `max_contacts` row for an extension id (misread by FreePBX as a trunk). 1.6.1 stopped creating such rows; 1.6.2 stops handing out credentials in that situation.

## 1.6.1
- Credentials message: "wait 60 seconds before registering", voicemail instructions (dial *97 or 6245), and a configurable support note (open a ticket by DMing). Error messages use the same note.
- Fix: ids already present in the PJSIP table (trunks, leftovers) are never offered as free extensions.
- Fix: the max-contacts setting no longer creates a stray PJSIP row if an endpoint has no data.
- New: **Users & Links** shows leftover PJSIP data from failed creations (ids inside your ranges with no extension) with a one-click cleanup. Leftovers can make Apply Config fail with `Undefined array key "trunk_name"`.

## 1.6.0
- New setting **Role that may choose ANY extension**: in "Ask the user" mode, holders of that role can request any free number (outside the ranges); everyone else must pick inside the range(s).

## 1.5.0
- New extensions get **max contacts = 50** (configurable, 1-200).
- New extensions get **voicemail enabled**. PIN options: the extension number (default), a random 6-digit PIN shown in the private reply, or disabled.

## 1.4.0
- **Multiple extensions per user, restricted.** By default one user = one extension. A **Role ID** and/or an **allowed-user list** (Settings) may hold several, up to a configurable maximum.
- Reset Password / Delete show an extension picker when the user owns several. `/mystatus`, `/dnd`, `/forward` and `/call` take an optional `extension` option; `/unlink` can target one extension.
- Admin links (`/link`, Users & Links tab) are not limited by the one-extension rule.
- Fix: the Delete confirmation button could be blocked by the cooldown started by the Delete click.
- Existing assignments migrate automatically on upgrade.

## 1.3.0
- **Extension ranges:** one or more ranges (e.g. `7000-7099, 7200-7299`); assignment is lowest-free, going up. Numbers used by other FreePBX objects are skipped.
- **Ask-the-user mode:** a Discord popup lets users request an extension; validated against the ranges, with the next free number suggested if taken.
- **Caller ID** / extension name is now just the Discord username (no "Discord" prefix); click-to-call uses the same name.
- **Linking:** `/link` and `/unlink` (admin, ship disabled) and a new **Users & Links** tab connect existing PBX extensions to Discord users.
- Linked extensions are never deleted or password-reset through Discord (the Delete button only unlinks).
- The bot never pings users from its replies.
- Old single start/end settings migrate to the ranges field on upgrade.

## 1.2.1
- Fix: extension creation crashed in FreePBX 17 (`Undefined array key "vm"` from the Voicemail Quick Create hook).
- Failed creations are rolled back and the real error is written to the bot log.
- `fwconsole discordprov` always returns JSON, even when PHP throws.

## 1.2.0
- Everything managed from the WebUI: **Bot** tab (Start/Stop/Restart, live log, checklist, dependency installer, connection test, invite link).
- Cron watchdog replaces systemd; saving settings restarts the bot automatically.
- Release workflow bundles bot dependencies so the module installs from Module Admin.

## 1.1.0
- FreePBX 17 only. Custom slash commands, Live Directory, acknowledge-before-work fix.

## 1.0.0
- Initial release.
