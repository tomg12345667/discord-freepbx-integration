# FreePBX Discord Provisioner

A **FreePBX 17** module + Node.js bot that connects your PBX to Discord, installed and managed entirely from the FreePBX web UI.

- **Self-service extensions** – embed with buttons (Create / Reset Password / Delete). Credentials arrive as **ephemeral** replies only the clicking user can see.
- **Ranges** – extensions only come from ranges you define, assigned lowest-free going up, or chosen by the user via a popup.
- **Link existing extensions** – `/link` in Discord or the *Users & Links* tab.
- **Custom slash commands** – map `/commands` to whitelisted PBX actions.
- **Live Directory** – auto-updating embed with online / offline / DND state.
- **Bot tab** – start/stop/restart, live logs, checklist, connection test, invite link.

## Install
**Admin → Module Admin → Upload Modules** → upload `discordprov-<version>.tgz` → Process → Install → Apply Config. Then open **Admin → Discord Provisioner**, fill in the Settings tab, use the invite link on the Bot tab, **Test connection**, **Start**.

Requires FreePBX 17 (PHP 8.2) and Node.js 18+. Only the Guilds intent is used. Invite with scopes `bot` + `applications.commands`.

## Extension assignment
Set ranges like `7000-7099, 7200-7299`. Two modes:
- **Automatic** – lowest free number in the ranges, going up.
- **Ask the user** – *Create Extension* opens a popup; the number must be inside your ranges and unused, otherwise the bot suggests the next free one.

The extension name / caller ID is the user's plain Discord username.

In *Ask the user* mode, members of the **"any extension" role** can request any free number, even outside the ranges. Everyone else must choose inside the range(s).

## One extension per user (or several, if allowed)
Everyone gets **one** extension by default. To let some people hold more, set on **Settings & Directory**:
- **Role ID allowed multiple extensions** – anyone with that Discord role, and/or
- **Discord user IDs allowed multiple extensions** – a comma-separated list,
- **Maximum extensions** for those users.

Reset/Delete ask which extension when a user owns several, and the `extension` option on `/dnd`, `/forward`, `/call`, `/mystatus` picks one. Admin links bypass the limit.

## Linking existing extensions
- **GUI:** *Users & Links* → paste the Discord user ID, pick the extension, **Link**.
- **Discord:** `/link user:@someone extension:101`, `/unlink user:@someone`. These ship **disabled**; set a **Required Role ID** on them in the *Commands* tab, then enable.

Linked extensions work with `/mystatus`, `/dnd`, `/forward`, `/call` and the directory, but the bot never deletes them or resets their password (Delete only unlinks).

## Commands
| Action | What it does | Options |
|---|---|---|
| My extension status | Registration, DND, forwarding | – |
| Toggle DND | AstDB `DND/<ext>` | on/off/toggle |
| Call forward | AstDB `CF/<ext>` | number (regex-checked) |
| Click-to-call | AMI Originate | number (regex-checked) |
| Show directory | Same data as Live Directory | – |
| Static text | Fixed reply | – |
| Link / Unlink *(admin)* | Link an existing extension | user, extension |
| PBX status / Reload *(admin)* | Health / `fwconsole reload` | role required |

There is deliberately no "run arbitrary shell command" action. Admin actions refuse to run without a Required Role ID.

## Security notes
- Treat the bot token like a root credential.
- Click-to-call and call-forward are toll-fraud surfaces; keep the internal-only default regexes and gate them with a role.
- Anyone controlling a Discord account that holds a bot-created extension can reset its password.

## License
GPL-3.0-or-later.
