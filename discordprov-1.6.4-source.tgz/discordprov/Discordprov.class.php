<?php
// SPDX-License-Identifier: GPL-3.0-or-later
namespace FreePBX\modules;

class Discordprov extends \DB_Helper implements \BMO {
	private $FreePBX;
	private $db;
	private $msg = '';
	private $msgClass = 'info';
	private $view = 'bot';
	private $editRow = null;

	const CRON = '* * * * * /usr/sbin/fwconsole discordprov watchdog > /dev/null 2>&1';

	const EXT_OPT = ['name' => 'extension', 'description' => 'Which of your extensions (only needed if you have several)', 'required' => false, 'choices' => []];
	const EXT_OPT_ADMIN = ['name' => 'extension', 'description' => 'Which extension to unlink (only needed if the user has several)', 'required' => false, 'choices' => []];

	const DEFAULTS = [
		'client_id' => '', 'token' => '', 'guild_id' => '', 'channel_id' => '', 'role_id' => '',
		'ext_ranges' => '7000-7999', 'ext_mode' => 'auto', 'any_role_id' => '', 'multi_role_id' => '', 'multi_user_ids' => '', 'multi_max' => '5', 'max_contacts' => '50', 'vm_mode' => 'ext', 'support_note' => 'For anything else, please open a support ticket by DMing.', 'sip_host' => '', 'sip_port' => '5060', 'auto_reload' => '1',
		'panel_message_id' => '', 'bot_enabled' => '0',
		'dir_channel_id' => '', 'dir_interval' => '60', 'dir_source' => 'discord', 'dir_mentions' => '1', 'dir_message_id' => '',
	];

	/**
	 * Catalog of safe, built-in actions a slash command can point at.
	 * There is intentionally NO "run arbitrary shell/CLI" action.
	 */
	const ACTIONS = [
		'ext_status' => [
			'label' => 'My extension status', 'needs_ext' => true, 'admin' => false, 'options' => [self::EXT_OPT],
			'desc' => "Shows registration, DND and call-forward state of the caller's extension.",
		],
		'dnd' => [
			'label' => 'Toggle Do Not Disturb', 'needs_ext' => true, 'admin' => false,
			'desc' => "Sets DND on the caller's extension.",
			'options' => [['name' => 'state', 'description' => 'on, off or toggle (default)', 'required' => false, 'choices' => ['on', 'off', 'toggle']], self::EXT_OPT],
		],
		'cfwd' => [
			'label' => 'Call forward (unconditional)', 'needs_ext' => true, 'admin' => false,
			'desc' => 'Sets or clears unconditional call forwarding. Number is checked against the allow pattern.',
			'options' => [['name' => 'number', 'description' => 'Forward to this number (leave empty to disable)', 'required' => false, 'choices' => []], self::EXT_OPT],
		],
		'click2call' => [
			'label' => 'Click-to-call', 'needs_ext' => true, 'admin' => false,
			'desc' => "Rings the caller's extension, then dials the number. Number is checked against the allow pattern.",
			'options' => [['name' => 'number', 'description' => 'Number to call', 'required' => true, 'choices' => []], self::EXT_OPT],
		],
		'directory' => [
			'label' => 'Show extension directory', 'needs_ext' => false, 'admin' => false, 'options' => [],
			'desc' => 'Prints the current directory (same data as the Live Directory).',
		],
		'static_text' => [
			'label' => 'Static text reply', 'needs_ext' => false, 'admin' => false, 'options' => [],
			'desc' => 'Replies with fixed text. {ext} is replaced with the caller\'s extension if they have one.',
		],
		'link' => [
			'label' => 'Link existing extension (admin)', 'needs_ext' => false, 'admin' => true,
			'desc' => 'Links an existing PBX extension to a Discord user. A required role is mandatory.',
			'options' => [
				['name' => 'user', 'type' => 'user', 'description' => 'Discord user to link', 'required' => true, 'choices' => []],
				['name' => 'extension', 'description' => 'Existing extension number', 'required' => true, 'choices' => []],
			],
		],
		'unlink' => [
			'label' => 'Unlink a user (admin)', 'needs_ext' => false, 'admin' => true,
			'desc' => 'Removes the Discord link only; the extension stays on the PBX. A required role is mandatory.',
			'options' => [['name' => 'user', 'type' => 'user', 'description' => 'Discord user to unlink', 'required' => true, 'choices' => []], self::EXT_OPT_ADMIN],
		],
		'pbx_status' => [
			'label' => 'PBX status (admin)', 'needs_ext' => false, 'admin' => true, 'options' => [],
			'desc' => 'Uptime, active calls and registered extension count. A required role is mandatory.',
		],
		'pbx_reload' => [
			'label' => 'Apply config / reload (admin)', 'needs_ext' => false, 'admin' => true, 'options' => [],
			'desc' => 'Runs fwconsole reload in the background. A required role is mandatory.',
		],
	];

	public function __construct($freepbx = null) {
		if ($freepbx === null) { throw new \Exception('Not given a FreePBX Object'); }
		$this->FreePBX = $freepbx;
		$this->db = $freepbx->Database;
	}

	/* ------------------------------------------------------------ lifecycle */

	public function install() {
		$this->db->exec("CREATE TABLE IF NOT EXISTS discordprov_commands (
			id INT AUTO_INCREMENT PRIMARY KEY,
			name VARCHAR(32) NOT NULL UNIQUE,
			description VARCHAR(100) NOT NULL,
			action VARCHAR(32) NOT NULL,
			params TEXT NULL,
			role_id VARCHAR(25) NOT NULL DEFAULT '',
			ephemeral TINYINT(1) NOT NULL DEFAULT 1,
			enabled TINYINT(1) NOT NULL DEFAULT 1
		) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4");

		if ($this->getConfig('ext_ranges') === false && $this->getConfig('ext_start') !== false) {
			$this->setConfig('ext_ranges', $this->getConfig('ext_start') . '-' . $this->getConfig('ext_end'));
		}
		foreach (self::DEFAULTS as $k => $v) {
			if ($this->getConfig($k) === false) { $this->setConfig($k, $v); }
		}
		if ($this->getConfig('owners_migrated') !== '1') {
			foreach (($this->getAll('users') ?: []) as $did => $ext) {
				$this->setConfig((string)$ext, (string)$did, 'owners');
				if ($this->getConfig((string)$did, 'linked') === '1') { $this->setConfig((string)$ext, '1', 'linked_ext'); }
			}
			$this->setConfig('owners_migrated', '1');
		}

		if ((int)$this->db->query('SELECT COUNT(*) FROM discordprov_commands')->fetchColumn() === 0) {
			$seed = [
				['mystatus', 'Show your extension status', 'ext_status', '{}', 1, 1],
				['dnd', 'Set Do Not Disturb on your extension', 'dnd', '{}', 1, 1],
				['forward', 'Forward your extension to another number', 'cfwd', '{"allow_pattern":"^\\\\d{2,15}$"}', 1, 1],
				['call', 'Call a number from your extension', 'click2call', '{"allow_pattern":"^\\\\d{2,6}$"}', 1, 1],
				['directory', 'Show the extension directory', 'directory', '{}', 1, 1],
				['pbxstatus', 'PBX health summary (set a role, then enable)', 'pbx_status', '{}', 1, 0],
			];
			$st = $this->db->prepare('INSERT INTO discordprov_commands (name, description, action, params, ephemeral, enabled) VALUES (?,?,?,?,?,?)');
			foreach ($seed as $row) { $st->execute($row); }
		}
		if ($this->getConfig('seed_link') !== '1') {
			$st = $this->db->prepare('INSERT IGNORE INTO discordprov_commands (name, description, action, params, ephemeral, enabled) VALUES (?,?,?,?,?,?)');
			$st->execute(['link', 'Link an existing extension to a Discord user (admin)', 'link', '{}', 1, 0]);
			$st->execute(['unlink', 'Unlink a Discord user from their extension (admin)', 'unlink', '{}', 1, 0]);
			$this->setConfig('seed_link', '1');
		}
	}

	public function uninstall() {
		try { $this->botStop(true); } catch (\Throwable $e) {}
		try { $this->FreePBX->Cron->remove(self::CRON); } catch (\Throwable $e) {}
		$this->db->exec('DROP TABLE IF EXISTS discordprov_commands');
	}
	public function backup() {}
	public function restore($backup) {}

	/* ------------------------------------------------------------- settings */

	public function getSettings() {
		$out = [];
		foreach (self::DEFAULTS as $k => $v) {
			$val = $this->getConfig($k);
			$out[$k] = ($val === false) ? $v : $val;
		}
		return $out;
	}

	/** Used by the bot for runtime bookkeeping (message ids). */
	public function setSetting($k, $v) {
		if (in_array($k, ['panel_message_id', 'dir_message_id'], true)) { $this->setConfig($k, $v); return true; }
		return false;
	}

	/** Called after any settings/command change: restart the bot so it picks them up. */
	private function applyChanges() {
		if ($this->getConfig('bot_enabled') !== '1') { return _('The bot is stopped - start it on the Bot tab.'); }
		$r = $this->botRestart();
		return $r['ok'] ? _('Bot restarted with the new settings.') : sprintf(_('Bot restart failed: %s'), $r['message']);
	}

	private function flash($msg, $class = 'info') { $this->msg = $msg; $this->msgClass = $class; }

	public function doConfigPageInit($page) {
		$this->view = in_array($_GET['view'] ?? '', ['bot', 'settings', 'users', 'commands'], true) ? $_GET['view'] : 'bot';
		if (($_SERVER['REQUEST_METHOD'] ?? '') !== 'POST') { return; }

		switch ($_POST['action'] ?? '') {
			case 'save':
				$this->saveSettingsFromPost();
				break;
			case 'cmd_save':
				$this->view = 'commands';
				[$ok, $m] = $this->saveCommand($_POST);
				$this->flash($m, $ok ? 'success' : 'danger');
				if (!$ok) { $this->editRow = $_POST; }
				break;
			case 'link_save':
				$this->view = 'users';
				$did = trim((string)($_POST['link_discord_id'] ?? ''));
				$name = '';
				if (ctype_digit($did) && $this->getConfig('token') && function_exists('curl_init')) {
					[$c, $u] = $this->discord('/users/' . $did);
					if ($c === 404) { $this->flash(_('Discord has no user with that ID.'), 'danger'); break; }
					if ($c === 200) { $name = (string)($u['username'] ?? ''); }
				}
				$r = $this->linkExtension($did, (string)($_POST['link_ext'] ?? ''), $name);
				$this->flash($r['ok'] ? sprintf(_('Linked %s to extension %s (%s).'), $name !== '' ? $name : $did, $r['extension'], $r['name']) : $r['message'], $r['ok'] ? 'success' : 'danger');
				break;
			case 'orphan_clean':
				$this->view = 'users';
				$n = $this->cleanOrphans();
				$this->flash(sprintf(_('Removed %d stray row(s) from the trunk table. Now click Apply Config in FreePBX.'), $n), 'success');
				break;
			case 'user_unlink':
				$this->view = 'users';
				$r = $this->unlinkUser((string)($_POST['discord_id'] ?? ''), (string)($_POST['ext'] ?? ''));
				$this->flash($r['ok'] ? sprintf(_('Unlinked extension %s (it still exists on the PBX).'), $r['extension']) : $r['message'], $r['ok'] ? 'success' : 'danger');
				break;
			case 'user_delete':
				$this->view = 'users';
				$did = (string)($_POST['discord_id'] ?? '');
				$r = ctype_digit($did) ? $this->remove($did, (string)($_POST['ext'] ?? '')) : ['ok' => false];
				if (!$r['ok']) { $this->flash(_('Could not remove that user.'), 'danger'); }
				else { $this->flash(!empty($r['unlinked']) ? sprintf(_('Unlinked extension %s (linked extensions are never deleted).'), $r['extension']) : sprintf(_('Extension %s removed.'), $r['extension']), 'success'); }
				break;
			case 'cmd_delete':
				$this->view = 'commands';
				$st = $this->db->prepare('DELETE FROM discordprov_commands WHERE id = ?');
				$st->execute([(int)($_POST['id'] ?? 0)]);
				$this->flash(_('Command deleted.') . ' ' . $this->applyChanges(), 'success');
				break;
		}
	}

	private function saveSettingsFromPost() {
		$v = fn($k) => trim((string)($_POST[$k] ?? ''));
		foreach (['client_id', 'guild_id', 'channel_id', 'role_id', 'dir_channel_id', 'multi_role_id', 'any_role_id'] as $k) {
			if ($v($k) !== '' && !ctype_digit($v($k))) { $this->flash(sprintf(_('%s must be a numeric Discord ID'), $k), 'danger'); return; }
		}
		$ranges = $this->parseRanges($v('ext_ranges'));
		if (!$ranges) { $this->flash(_('Invalid extension ranges. Use e.g. 7000-7099, 7200-7299'), 'danger'); return; }
		$multiIds = preg_split('/[\s,]+/', $v('multi_user_ids'), -1, PREG_SPLIT_NO_EMPTY);
		foreach ($multiIds as $x) { if (!ctype_digit($x)) { $this->flash(_('Allowed-user list must contain numeric Discord user IDs, separated by commas'), 'danger'); return; } }
		$multiMax = (int)$v('multi_max');
		if ($multiMax < 1 || $multiMax > 50) { $this->flash(_('Max extensions must be between 1 and 50'), 'danger'); return; }
		$maxContacts = (int)$v('max_contacts');
		if ($maxContacts < 1 || $maxContacts > 200) { $this->flash(_('Max contacts must be between 1 and 200'), 'danger'); return; }
		$interval = (int)$v('dir_interval');
		if ($interval < 30 || $interval > 3600) { $this->flash(_('Directory interval must be 30-3600 seconds'), 'danger'); return; }

		foreach (['client_id', 'guild_id', 'channel_id', 'role_id', 'dir_channel_id', 'multi_role_id', 'any_role_id'] as $k) { $this->setConfig($k, $v($k)); }
		if ($v('token') !== '') { $this->setConfig('token', $v('token')); }
		$this->setConfig('multi_user_ids', implode(', ', array_unique($multiIds)));
		$this->setConfig('multi_max', (string)$multiMax);
		$this->setConfig('max_contacts', (string)$maxContacts);
		$this->setConfig('support_note', mb_substr($v('support_note'), 0, 200));
		$this->setConfig('vm_mode', in_array($v('vm_mode'), ['off', 'ext', 'random'], true) ? $v('vm_mode') : 'ext');
		$this->setConfig('ext_ranges', $this->rangesToString($ranges));
		$this->setConfig('ext_mode', $v('ext_mode') === 'ask' ? 'ask' : 'auto');
		$this->setConfig('sip_host', preg_replace('/[^A-Za-z0-9.\-:]/', '', $v('sip_host')));
		$this->setConfig('sip_port', (string)((int)$v('sip_port') ?: 5060));
		$this->setConfig('auto_reload', isset($_POST['auto_reload']) ? '1' : '0');
		$this->setConfig('dir_interval', (string)$interval);
		$this->setConfig('dir_source', $v('dir_source') === 'all' ? 'all' : 'discord');
		$this->setConfig('dir_mentions', isset($_POST['dir_mentions']) ? '1' : '0');
		if (isset($_POST['repost'])) { $this->setConfig('panel_message_id', ''); }
		if (isset($_POST['repost_dir'])) { $this->setConfig('dir_message_id', ''); }
		$this->flash(_('Saved.') . ' ' . $this->applyChanges(), 'success');
	}

	public function showPage() {
		$edit = $this->editRow;
		if ($edit === null && isset($_GET['edit'])) { $edit = $this->getCommandById((int)$_GET['edit']); }
		return load_view(__DIR__ . '/views/main.php', [
			'view' => $this->view, 's' => $this->getSettings(), 'msg' => $this->msg, 'msgClass' => $this->msgClass,
			'owners' => $this->ownersSorted(), 'commands' => $this->listCommands(),
			'linked' => $this->getAll('linked_ext') ?: [], 'names' => $this->getAll('names') ?: [],
			'pbx_exts' => ($this->view === 'users') ? $this->unlinkedPbxExtensions() : [],
			'orphans' => ($this->view === 'users') ? $this->orphanedPjsipIds() : [],
			'edit' => $edit, 'actions' => self::ACTIONS,
			'bot' => ($this->view === 'bot') ? $this->botStatus() : null,
			'invite' => $this->inviteUrl(),
		]);
	}

	/* ------------------------------------------------------ command registry */

	public function listCommands() {
		return $this->db->query('SELECT * FROM discordprov_commands ORDER BY name')->fetchAll(\PDO::FETCH_ASSOC);
	}
	private function getCommandById($id) {
		$st = $this->db->prepare('SELECT * FROM discordprov_commands WHERE id = ?'); $st->execute([$id]);
		return $st->fetch(\PDO::FETCH_ASSOC) ?: null;
	}
	private function getCommandByName($name) {
		$st = $this->db->prepare('SELECT * FROM discordprov_commands WHERE name = ?'); $st->execute([$name]);
		return $st->fetch(\PDO::FETCH_ASSOC) ?: null;
	}

	public function saveCommand(array $in) {
		$id = (int)($in['id'] ?? 0);
		$name = strtolower(trim($in['name'] ?? ''));
		$desc = trim($in['description'] ?? '');
		$action = $in['cmd_action'] ?? '';
		$role = trim($in['cmd_role_id'] ?? '');

		if (!preg_match('/^[a-z0-9_-]{1,32}$/', $name)) { return [false, _('Name must be 1-32 chars: a-z, 0-9, _ or -')]; }
		if ($desc === '' || mb_strlen($desc) > 100) { return [false, _('Description is required (max 100 chars)')]; }
		if (!isset(self::ACTIONS[$action])) { return [false, _('Unknown action')]; }
		if ($role !== '' && !ctype_digit($role)) { return [false, _('Role ID must be numeric')]; }
		if (self::ACTIONS[$action]['admin'] && $role === '') { return [false, _('This action is admin-level: a required Role ID must be set')]; }

		$params = [];
		if ($action === 'static_text') {
			$t = trim($in['text'] ?? '');
			if ($t === '' || mb_strlen($t) > 1800) { return [false, _('Reply text is required (max 1800 chars)')]; }
			$params['text'] = $t;
		}
		if ($action === 'click2call' || $action === 'cfwd') {
			$p = trim($in['allow_pattern'] ?? '');
			if ($p === '') { $p = ($action === 'click2call') ? '^\d{2,6}$' : '^\d{2,15}$'; }
			if (strpos($p, '~') !== false || @preg_match('~' . $p . '~', '') === false) { return [false, _('Allow pattern is not a valid regex (do not use ~)')]; }
			$params['allow_pattern'] = $p;
		}

		$vals = [$name, $desc, $action, json_encode($params), $role, isset($in['ephemeral']) ? 1 : 0, isset($in['enabled']) ? 1 : 0];
		try {
			if ($id > 0) {
				$st = $this->db->prepare('UPDATE discordprov_commands SET name=?, description=?, action=?, params=?, role_id=?, ephemeral=?, enabled=? WHERE id=?');
				$st->execute(array_merge($vals, [$id]));
			} else {
				$st = $this->db->prepare('INSERT INTO discordprov_commands (name, description, action, params, role_id, ephemeral, enabled) VALUES (?,?,?,?,?,?,?)');
				$st->execute($vals);
			}
		} catch (\PDOException $e) {
			return [false, _('Could not save (is the command name already used?)')];
		}
		return [true, _('Command saved.') . ' ' . $this->applyChanges()];
	}

	/** Enabled commands in the shape the bot needs to register and gate them. */
	public function commandsForBot() {
		$out = [];
		foreach ($this->listCommands() as $r) {
			if (!(int)$r['enabled'] || !isset(self::ACTIONS[$r['action']])) { continue; }
			$a = self::ACTIONS[$r['action']];
			$out[] = ['name' => $r['name'], 'description' => $r['description'], 'action' => $r['action'],
				'role_id' => $r['role_id'], 'ephemeral' => (bool)(int)$r['ephemeral'],
				'admin' => $a['admin'], 'options' => $a['options']];
		}
		return $out;
	}

	/* ---------------------------------------------------------- AMI helpers */

	private function ami() {
		$am = $this->FreePBX->astman;
		return ($am && $am->connected()) ? $am : null;
	}

	private function amiText($cmd) {
		$am = $this->ami();
		if (!$am) { return null; }
		try { $r = $am->Command($cmd); } catch (\Throwable $e) { return null; }
		return is_array($r) ? (string)($r['data'] ?? '') : (string)$r;
	}

	/** @return array|null  ext => true for registered endpoints, null if AMI is down */
	private function onlineExtensions() {
		$txt = $this->amiText('pjsip show contacts');
		if ($txt === null) { return null; }
		$on = [];
		if (preg_match_all('~Contact:\s+([^/\s]+)/sip:\S+\s+\S+\s+(Avail|NonQual)~', $txt, $m)) {
			foreach ($m[1] as $e) { $on[$e] = true; }
		}
		return $on;
	}

	private function astdbFamily($family) {
		$am = $this->ami();
		if (!$am) { return []; }
		try { $r = $am->database_show($family); } catch (\Throwable $e) { return []; }
		$out = [];
		foreach ((array)$r as $k => $v) { $out[basename($k)] = $v; }
		return $out;
	}

	/* ------------------------------------------------------------ directory */

	public function directory() {
		$s = $this->getSettings();
		$map = [];
		foreach (($this->getAll('owners') ?: []) as $ext => $did) { $map[(string)$ext] = (string)$did; }
		$rows = $this->db->query('SELECT extension, name FROM users ORDER BY CAST(extension AS UNSIGNED)')->fetchAll(\PDO::FETCH_ASSOC);
		$online = $this->onlineExtensions();
		$dnd = $this->astdbFamily('DND');
		$out = [];
		foreach ($rows as $r) {
			$e = (string)$r['extension'];
			if ($s['dir_source'] === 'discord' && !isset($map[$e])) { continue; }
			$out[] = [
				'ext' => $e, 'name' => $r['name'],
				'online' => ($online === null) ? null : isset($online[$e]),
				'dnd' => (($dnd[$e] ?? '') === 'YES'),
				'discord_id' => ($s['dir_mentions'] === '1') ? ($map[$e] ?? null) : null,
			];
		}
		return $out;
	}

	/* ------------------------------------------------------ command runner */

	private function fail($msg) { return ['ok' => false, 'message' => $msg]; }

	public function run($name, $discordId, array $opts) {
		$cmd = $this->getCommandByName($name);
		if (!$cmd || !(int)$cmd['enabled']) { return $this->fail('Unknown or disabled command.'); }
		$def = self::ACTIONS[$cmd['action']] ?? null;
		if (!$def) { return $this->fail('Command has an unknown action.'); }
		if ($def['admin'] && $cmd['role_id'] === '') { return $this->fail('This command requires a role to be configured.'); }
		$params = json_decode($cmd['params'] ?: '{}', true) ?: [];
		$owned = $this->ownedBy($discordId);
		$ext = null;
		if ($def['needs_ext']) {
			$want = trim((string)($opts['extension'] ?? ''));
			if (!$owned) { return $this->fail('You do not have an extension yet. Use the panel\'s Create Extension button first.'); }
			if ($want !== '') {
				if (!in_array($want, $owned, true)) { return $this->fail("Extension $want is not yours. Yours: " . implode(', ', $owned) . '.'); }
				$ext = $want;
			} elseif (count($owned) === 1) {
				$ext = $owned[0];
			} else {
				return $this->fail('You have several extensions (' . implode(', ', $owned) . '). Add the `extension` option to pick one.');
			}
		} else {
			$ext = $owned[0] ?? null;
		}

		switch ($cmd['action']) {
			case 'static_text':
				return ['ok' => true, 'title' => ucfirst($cmd['name']), 'lines' => [str_replace('{ext}', (string)$ext, $params['text'] ?? '')]];
			case 'link':
				$r = $this->linkExtension((string)($opts['user'] ?? ''), (string)($opts['extension'] ?? ''), (string)($opts['user_name'] ?? ''));
				if (!$r['ok']) { return $r; }
				return ['ok' => true, 'title' => 'Extension linked', 'lines' => ["<@{$opts['user']}> is now linked to extension **{$r['extension']}** ({$r['name']})."]];
			case 'unlink':
				$r = $this->unlinkUser((string)($opts['user'] ?? ''), (string)($opts['extension'] ?? ''));
				if (!$r['ok']) { return $r; }
				return ['ok' => true, 'title' => 'User unlinked', 'lines' => ["<@{$opts['user']}> was unlinked from extension **{$r['extension']}** (it still exists on the PBX)."]];
			case 'directory':
				$lines = [];
				foreach ($this->directory() as $r) {
					$icon = $r['online'] === null ? '⚪' : ($r['dnd'] ? '🔴' : ($r['online'] ? '🟢' : '⚫'));
					$lines[] = "$icon **{$r['ext']}** - {$r['name']}";
				}
				return ['ok' => true, 'title' => 'Extension Directory', 'lines' => $lines ?: ['_No extensions to show._']];
		}

		$am = $this->ami();
		if (!$am) { return $this->fail('The PBX is not reachable via AMI right now.'); }

		switch ($cmd['action']) {
			case 'ext_status':
				$on = $this->onlineExtensions();
				$cf = $am->database_get('CF', $ext);
				return ['ok' => true, 'title' => "Extension $ext", 'lines' => [
					'Registration: ' . ($on === null ? 'unknown' : (isset($on[$ext]) ? '🟢 online' : '⚫ offline')),
					'Do Not Disturb: ' . ($am->database_get('DND', $ext) === 'YES' ? '🔴 on' : 'off'),
					'Call forward: ' . ($cf ? "to `$cf`" : 'off'),
				]];

			case 'dnd':
				$state = $opts['state'] ?? 'toggle';
				$cur = ($am->database_get('DND', $ext) === 'YES');
				$new = ($state === 'on') ? true : (($state === 'off') ? false : !$cur);
				if ($new) { $am->database_put('DND', $ext, 'YES'); } else { $am->database_del('DND', $ext); }
				$am->Command('devstate change Custom:DND' . $ext . ' ' . ($new ? 'BUSY' : 'NOT_INUSE'));
				return ['ok' => true, 'title' => 'Do Not Disturb', 'lines' => ["Extension $ext: DND is now **" . ($new ? 'ON' : 'OFF') . '**.']];

			case 'cfwd':
				$num = trim((string)($opts['number'] ?? ''));
				if ($num === '') {
					$am->database_del('CF', $ext);
					$am->Command('devstate change Custom:CF' . $ext . ' NOT_INUSE');
					return ['ok' => true, 'title' => 'Call forward', 'lines' => ["Extension $ext: forwarding **disabled**."]];
				}
				$pat = $params['allow_pattern'] ?? '^\d{2,15}$';
				if (!preg_match('~' . $pat . '~', $num)) { return $this->fail('That number is not allowed for forwarding.'); }
				$am->database_put('CF', $ext, $num);
				$am->Command('devstate change Custom:CF' . $ext . ' INUSE');
				return ['ok' => true, 'title' => 'Call forward', 'lines' => ["Extension $ext now forwards to `$num`."]];

			case 'click2call':
				$num = trim((string)($opts['number'] ?? ''));
				$pat = $params['allow_pattern'] ?? '^\d{2,6}$';
				if (!preg_match('/^[0-9*+#]{1,20}$/', $num) || !preg_match('~' . $pat . '~', $num)) { return $this->fail('That number is not allowed.'); }
				$st = $this->db->prepare('SELECT name FROM users WHERE extension = ?');
				$st->execute([$ext]);
				$cn = trim(preg_replace('/[^A-Za-z0-9 _.\-]/', '', (string)$st->fetchColumn()));
				$res = $am->send_request('Originate', [
					'Channel' => "Local/$ext@from-internal", 'Context' => 'from-internal', 'Exten' => $num, 'Priority' => 1,
					'CallerID' => ($cn !== '' ? "\"$cn\" " : '') . "<$ext>", 'Async' => 'true', 'Timeout' => 30000,
				]);
				if (is_array($res) && (($res['Response'] ?? '') === 'Error')) { return $this->fail('The PBX refused to start the call.'); }
				return ['ok' => true, 'title' => 'Click-to-call', 'lines' => ["Ringing extension **$ext** now. Answer to be connected to `$num`."]];

			case 'pbx_status':
				$up = $this->amiText('core show uptime') ?? '';
				$ch = $this->amiText('core show channels count') ?? '';
				$on = $this->onlineExtensions();
				$lines = [];
				if (preg_match('/System uptime:\s*(.+)/', $up, $m)) { $lines[] = 'Uptime: ' . trim($m[1]); }
				if (preg_match('/(\d+) active channel/', $ch, $m)) { $lines[] = 'Active channels: ' . $m[1]; }
				if (preg_match('/(\d+) active call/', $ch, $m)) { $lines[] = 'Active calls: ' . $m[1]; }
				$lines[] = 'Registered extensions: ' . ($on === null ? 'unknown' : count($on));
				return ['ok' => true, 'title' => 'PBX status', 'lines' => $lines];

			case 'pbx_reload':
				$this->reload(true);
				return ['ok' => true, 'title' => 'Reload', 'lines' => ['Reload started in the background.']];
		}
		return $this->fail('Unhandled action.');
	}

	/* ------------------------------------------------------ ownership / linking
	 * Storage: group "owners"     ext => discord id
	 *          group "linked_ext" ext => '1' when the extension pre-existed (never deleted/reset by the bot)
	 *          group "names"      discord id => username                                              */

	private function ownersSorted() {
		$o = $this->getAll('owners') ?: [];
		ksort($o, SORT_NUMERIC);
		return $o;
	}

	private function ownedBy($did) {
		$out = [];
		foreach (($this->getAll('owners') ?: []) as $ext => $d) {
			if ((string)$d === (string)$did) { $out[] = (string)$ext; }
		}
		sort($out, SORT_NUMERIC);
		return $out;
	}

	private function ownerOf($ext) {
		$d = $this->getConfig((string)$ext, 'owners');
		return $d ? (string)$d : null;
	}

	private function isLinkedExt($ext) { return $this->getConfig((string)$ext, 'linked_ext') === '1'; }

	/** @return array [ext|null, error|null, owned list]  error: none | not_owner | choose */
	private function resolveOwned($did, $ext) {
		$owned = $this->ownedBy($did);
		if (!$owned) { return [null, 'none', []]; }
		$ext = trim((string)$ext);
		if ($ext !== '') { return in_array($ext, $owned, true) ? [$ext, null, $owned] : [null, 'not_owner', $owned]; }
		if (count($owned) === 1) { return [$owned[0], null, $owned]; }
		return [null, 'choose', $owned];
	}

	/** One extension per user, unless they hold the multi role (flag from the bot) or are on the allowed list. */
	private function extensionLimit($did, $hasMultiRole) {
		$ids = preg_split('/[\s,]+/', (string)$this->getConfig('multi_user_ids'), -1, PREG_SPLIT_NO_EMPTY);
		if ($hasMultiRole || in_array((string)$did, $ids, true)) { return max(1, (int)$this->getConfig('multi_max')); }
		return 1;
	}

	private function dropOwnership($ext, $did) {
		$this->delConfig((string)$ext, 'owners');
		$this->delConfig((string)$ext, 'linked_ext');
		if (!$this->ownedBy($did)) { $this->delConfig((string)$did, 'names'); }
	}

	/** Link an EXISTING PBX extension to a Discord user (admin action, so the per-user limit is not applied). */
	public function linkExtension($did, $ext, $name = '') {
		$did = trim((string)$did);
		$ext = trim((string)$ext);
		if (!ctype_digit($did)) { return $this->fail('That is not a valid Discord user.'); }
		if (!ctype_digit($ext)) { return $this->fail('The extension must be a number.'); }
		$st = $this->db->prepare('SELECT name FROM users WHERE extension = ?');
		$st->execute([$ext]);
		$pbxName = $st->fetchColumn();
		if ($pbxName === false) { return $this->fail("Extension $ext does not exist on the PBX."); }
		$cur = $this->ownerOf($ext);
		if ($cur) { return $this->fail("Extension $ext is already linked to <@$cur>."); }
		$this->setConfig($ext, $did, 'owners');
		$this->setConfig($ext, '1', 'linked_ext');
		if ($name !== '') { $this->setConfig($did, substr((string)$name, 0, 32), 'names'); }
		return ['ok' => true, 'extension' => $ext, 'name' => (string)$pbxName];
	}

	/** Drop the Discord <-> extension link. The extension itself is left untouched on the PBX. */
	public function unlinkUser($did, $ext = '') {
		$did = trim((string)$did);
		if (!ctype_digit($did)) { return $this->fail('That is not a valid Discord user.'); }
		[$e, $err, $owned] = $this->resolveOwned($did, $ext);
		if ($err === 'none') { return $this->fail('That user has no linked extension.'); }
		if ($err === 'not_owner') { return $this->fail('Extension ' . trim((string)$ext) . ' does not belong to that user. Theirs: ' . implode(', ', $owned) . '.'); }
		if ($err === 'choose') { return $this->fail('That user has several extensions (' . implode(', ', $owned) . '). Specify the extension.'); }
		$this->dropOwnership($e, $did);
		return ['ok' => true, 'extension' => $e];
	}

	/** Stray rows in the trunk (`pjsip`) table holding only `max_contacts` (left by module versions 1.5.0-1.6.1). */
	public function orphanedPjsipIds() {
		$rows = $this->db->query("SELECT id FROM pjsip GROUP BY id HAVING SUM(keyword <> 'max_contacts') = 0")->fetchAll(\PDO::FETCH_COLUMN);
		$out = [];
		foreach ($rows as $id) {
			$isTrunk = false;
			try {
				$st = $this->db->prepare('SELECT COUNT(*) FROM trunks WHERE trunkid = ?');
				$st->execute([$id]);
				$isTrunk = ((int)$st->fetchColumn() > 0);
			} catch (\Throwable $e) {}
			if (!$isTrunk) { $out[] = (string)$id; }
		}
		sort($out, SORT_NUMERIC);
		return $out;
	}

	public function cleanOrphans() {
		$ids = $this->orphanedPjsipIds();
		if (!$ids) { return 0; }
		$st = $this->db->prepare("DELETE FROM pjsip WHERE id = ? AND keyword = 'max_contacts'");
		foreach ($ids as $id) { $st->execute([$id]); }
		needreload();
		return count($ids);
	}

	private function unlinkedPbxExtensions() {
		$taken = array_flip(array_map('strval', array_keys($this->getAll('owners') ?: [])));
		$out = [];
		foreach ($this->db->query('SELECT extension, name FROM users ORDER BY CAST(extension AS UNSIGNED)')->fetchAll(\PDO::FETCH_ASSOC) as $r) {
			if (!isset($taken[(string)$r['extension']])) { $out[] = $r; }
		}
		return $out;
	}

	/* --------------------------------------------------------- provisioning */

	private function reload($force = false) {
		needreload();
		if ($force || $this->getConfig('auto_reload') === '1') {
			exec('(flock ' . escapeshellarg($this->runDir() . '/discordprov.reload.lock') . ' /usr/sbin/fwconsole reload >/dev/null 2>&1 &)');
		}
	}

	private function newSecret() { return bin2hex(random_bytes(12)); }

	/** "7000-7099, 7200" -> [[7000,7099],[7200,7200]] or null when invalid. */
	private function parseRanges($str) {
		$out = [];
		foreach (explode(',', (string)$str) as $part) {
			if (!preg_match('/^(\d{1,10})(?:\s*-\s*(\d{1,10}))?$/', trim($part), $m)) { return null; }
			$a = (int)$m[1];
			$b = (isset($m[2]) && $m[2] !== '') ? (int)$m[2] : $a;
			if ($a < 1 || $b < $a || ($b - $a) > 100000) { return null; }
			$out[] = [$a, $b];
		}
		return $out ?: null;
	}

	private function rangesToString(array $ranges) {
		return implode(', ', array_map(fn($r) => $r[0] === $r[1] ? (string)$r[0] : $r[0] . '-' . $r[1], $ranges));
	}

	private function inRanges($n, array $ranges) {
		foreach ($ranges as [$a, $b]) { if ($n >= $a && $n <= $b) { return true; } }
		return false;
	}

	private function usedExtensions() {
		$users = $this->db->query('SELECT extension FROM users')->fetchAll(\PDO::FETCH_COLUMN);
		// PJSIP trunks and endpoints share one id namespace in the pjsip table, so those ids are taken too.
		$pjsip = $this->db->query('SELECT DISTINCT id FROM pjsip')->fetchAll(\PDO::FETCH_COLUMN);
		$sip = $this->db->query('SELECT DISTINCT id FROM sip')->fetchAll(\PDO::FETCH_COLUMN);
		return array_flip(array_map('strval', array_merge($users, $pjsip, $sip)));
	}

	/** Free = no user with that number and no other FreePBX object (ring group, conference...) using it. */
	private function extensionFree($ext, array $used) {
		if (isset($used[(string)$ext])) { return false; }
		if (function_exists('framework_check_extension_usage')) {
			try {
				$u = framework_check_extension_usage((string)$ext);
				if (!empty($u)) { return false; }
			} catch (\Throwable $e) {}
		}
		return true;
	}

	/** Lowest free extension, walking each range upwards in the order given. */
	private function nextExtension(array $ranges) {
		$used = $this->usedExtensions();
		foreach ($ranges as [$a, $b]) {
			for ($i = $a; $i <= $b; $i++) {
				if ($this->extensionFree($i, $used)) { return (string)$i; }
			}
		}
		return null;
	}

	public function status($discordId) {
		$owned = $this->ownedBy($discordId);
		if (!$owned) { return ['ok' => false, 'error' => 'none']; }
		$linked = [];
		foreach ($owned as $e) { if ($this->isLinkedExt($e)) { $linked[$e] = true; } }
		return ['ok' => true, 'extension' => $owned[0], 'extensions' => $owned, 'linked' => (object)$linked];
	}

	public function provision($discordId, $username, $requested = '', $hasMultiRole = false, $anyExt = false) {
		$s = $this->getSettings();
		$lock = fopen($this->runDir() . '/discordprov.alloc.lock', 'c');
		flock($lock, LOCK_EX);
		try {
			$owned = $this->ownedBy($discordId);
			$limit = $this->extensionLimit($discordId, $hasMultiRole);
			if (count($owned) >= $limit) {
				return ['ok' => false, 'error' => $limit > 1 ? 'limit' : 'exists', 'extension' => $owned[0], 'extensions' => $owned, 'max' => $limit];
			}
			$ranges = $this->parseRanges($s['ext_ranges']) ?: [[7000, 7999]];
			$requested = trim((string)$requested);
			if ($s['ext_mode'] === 'ask' && $requested !== '') {
				if (!ctype_digit($requested) || strlen($requested) > 10) { return ['ok' => false, 'error' => 'bad_ext']; }
				$n = (int)$requested;
				// Only holders of the "any extension" role may choose outside the configured ranges.
				if (!$anyExt && !$this->inRanges($n, $ranges)) { return ['ok' => false, 'error' => 'out_of_range', 'ranges' => $this->rangesToString($ranges)]; }
				$ext = (string)$n;
				if (!$this->extensionFree($ext, $this->usedExtensions())) {
					return ['ok' => false, 'error' => 'taken', 'next' => $this->nextExtension($ranges)];
				}
			} else {
				$ext = $this->nextExtension($ranges);
				if ($ext === null) { return ['ok' => false, 'error' => 'range_full']; }
			}
			$secret = $this->newSecret();
			$vmMode = in_array($s['vm_mode'], ['off', 'ext', 'random'], true) ? $s['vm_mode'] : 'ext';
			$vmPin = ($vmMode === 'ext') ? $ext : (($vmMode === 'random') ? sprintf('%06d', random_int(0, 999999)) : '');
			$name = trim(substr(preg_replace('/[^A-Za-z0-9 _.\-]/', '', $username), 0, 30)) ?: 'discord-user';
			try {
				// Other modules (Voicemail, User Manager) hook Quick Create and read these keys.
				$res = $this->FreePBX->Core->processQuickCreate('pjsip', $ext, [
					'name' => $name, 'outboundcid' => '', 'email' => '', 'secret' => $secret,
					'vm' => ($vmMode === 'off' ? 'no' : 'yes'), 'vmpwd' => $vmPin, 'um' => 'no', 'umgroup' => '',
				]);
				if (is_array($res) && isset($res['status']) && !$res['status']) {
					throw new \Exception($res['message'] ?? 'Quick Create failed');
				}
				// Never hand out credentials for an endpoint that was not actually written.
				$chk = $this->db->prepare("SELECT COUNT(*) FROM `sip` WHERE `id` = ? AND `keyword` = 'secret'");
				$chk->execute([$ext]);
				if ((int)$chk->fetchColumn() === 0) { throw new \Exception("Quick Create wrote no endpoint data (sip table) for extension $ext"); }
			} catch (\Throwable $e) {
				// Quick Create may have half-created the extension: roll back so no orphan is left behind.
				$this->dropMailbox($ext);
				try { $this->FreePBX->Core->delDevice($ext); } catch (\Throwable $x) {}
				try { $this->FreePBX->Core->delUser($ext); } catch (\Throwable $x) {}
				try { $this->db->prepare('DELETE FROM `sip` WHERE `id` = ?')->execute([$ext]); } catch (\Throwable $x) {}
				needreload();
				return ['ok' => false, 'error' => 'create_failed', 'detail' => $e->getMessage()];
			}
			$this->setSecret($ext, $secret); // guarantee the stored secret is the one we hand out
			$this->setMaxContacts($ext, (int)$s['max_contacts']);
			$this->setConfig($ext, (string)$discordId, 'owners');
			$this->setConfig((string)$discordId, substr((string)$username, 0, 32), 'names');
			$this->reload();
			return $this->creds($ext, $secret, $s) + ['voicemail' => ['mode' => $vmMode, 'pin' => ($vmMode === 'random' ? $vmPin : '')]];
		} finally {
			flock($lock, LOCK_UN); fclose($lock);
		}
	}

	public function resetSecret($discordId, $ext = '') {
		[$e, $err, $owned] = $this->resolveOwned($discordId, $ext);
		if ($err) { return ['ok' => false, 'error' => $err, 'extensions' => $owned]; }
		if ($this->isLinkedExt($e)) { return ['ok' => false, 'error' => 'linked']; }
		$secret = $this->newSecret();
		$this->setSecret($e, $secret);
		$this->reload();
		return $this->creds($e, $secret, $this->getSettings());
	}

	public function remove($discordId, $ext = '') {
		[$e, $err, $owned] = $this->resolveOwned($discordId, $ext);
		if ($err) { return ['ok' => false, 'error' => $err, 'extensions' => $owned]; }
		if ($this->isLinkedExt($e)) {
			// Pre-existing extension: only drop the link, never delete it from the PBX.
			$this->dropOwnership($e, $discordId);
			return ['ok' => true, 'extension' => $e, 'unlinked' => true];
		}
		$this->dropMailbox($e);
		$this->FreePBX->Core->delDevice($e);
		$this->FreePBX->Core->delUser($e);
		$this->dropOwnership($e, $discordId);
		$this->reload();
		return ['ok' => true, 'extension' => $e];
	}

	private function setMaxContacts($ext, $n) {
		// Extension settings (also for PJSIP) live in the `sip` table; `pjsip` is trunks only.
		$st = $this->db->prepare('SELECT COUNT(*) FROM `sip` WHERE `id` = ?');
		$st->execute([$ext]);
		if ((int)$st->fetchColumn() === 0) { return; } // no endpoint data: do not create a stray row
		$st = $this->db->prepare("SELECT COUNT(*) FROM `sip` WHERE `id` = ? AND `keyword` = 'max_contacts'");
		$st->execute([$ext]);
		if ((int)$st->fetchColumn() > 0) {
			$st = $this->db->prepare("UPDATE `sip` SET `data` = ? WHERE `id` = ? AND `keyword` = 'max_contacts'");
			$st->execute([(string)$n, $ext]);
		} else {
			$st = $this->db->prepare("INSERT INTO `sip` (`id`, `keyword`, `data`, `flags`) VALUES (?, 'max_contacts', ?, 0)");
			$st->execute([$ext, (string)$n]);
		}
	}

	/** Best-effort mailbox cleanup; Core's delete hooks normally handle it, this is a safety net. */
	private function dropMailbox($ext) {
		try {
			$vm = $this->FreePBX->Voicemail;
			if ($vm && method_exists($vm, 'delMailbox')) { $vm->delMailbox($ext); }
		} catch (\Throwable $e) {}
	}

	private function setSecret($ext, $secret) {
		$st = $this->db->prepare("UPDATE `sip` SET `data` = ? WHERE `id` = ? AND `keyword` = 'secret'");
		$st->execute([$secret, $ext]);
	}

	private function creds($ext, $secret, $s) {
		return ['ok' => true, 'extension' => $ext, 'secret' => $secret,
			'host' => $s['sip_host'] ?: ($_SERVER['SERVER_NAME'] ?? gethostname()), 'port' => $s['sip_port']];
	}

	/* ============================================================ bot process
	 * The bot is a plain Node process owned by the web/asterisk user. A cron
	 * watchdog (installed from the GUI) restarts it after crashes/reboots.   */

	private function runDir() { return rtrim($this->FreePBX->Config->get('ASTRUNDIR') ?: '/var/run/asterisk', '/'); }
	private function logDir() { return rtrim($this->FreePBX->Config->get('ASTLOGDIR') ?: '/var/log/asterisk', '/'); }

	private function paths() {
		return [
			'botdir' => __DIR__ . '/bot',
			'pid' => $this->runDir() . '/discordprov-bot.pid',
			'log' => $this->logDir() . '/discordprov-bot.log',
			'npmpid' => $this->runDir() . '/discordprov-npm.pid',
			'npmlog' => $this->logDir() . '/discordprov-npm.log',
		];
	}

	private function findNode() {
		foreach (['/usr/bin/node', '/usr/local/bin/node', '/usr/bin/nodejs', '/opt/node/bin/node'] as $p) {
			if (is_executable($p)) { return $p; }
		}
		$w = trim((string)shell_exec('command -v node 2>/dev/null'));
		return ($w !== '' && is_executable($w)) ? $w : null;
	}

	private function findNpm($node) {
		if ($node && is_executable(dirname($node) . '/npm')) { return dirname($node) . '/npm'; }
		$w = trim((string)shell_exec('command -v npm 2>/dev/null'));
		return ($w !== '' && is_executable($w)) ? $w : null;
	}

	private function alive($pid, $needle) {
		if ($pid < 1 || !is_dir("/proc/$pid")) { return false; }
		return strpos((string)@file_get_contents("/proc/$pid/cmdline"), $needle) !== false;
	}

	private function readPid($file) { return is_file($file) ? (int)trim((string)@file_get_contents($file)) : 0; }

	private function tail($file, $lines = 200) {
		if (!is_file($file)) { return ''; }
		$size = filesize($file);
		$fh = fopen($file, 'rb');
		if (!$fh) { return ''; }
		if ($size > 65536) { fseek($fh, -65536, SEEK_END); }
		$data = (string)stream_get_contents($fh);
		fclose($fh);
		return implode("\n", array_slice(explode("\n", $data), -$lines));
	}

	public function hasWatchdog() {
		try {
			foreach ((array)$this->FreePBX->Cron->getAll() as $l) {
				if (strpos((string)$l, 'discordprov watchdog') !== false) { return true; }
			}
		} catch (\Throwable $e) {}
		return false;
	}

	private function ensureWatchdog() {
		if ($this->hasWatchdog()) { return true; }
		try { $this->FreePBX->Cron->add(self::CRON); } catch (\Throwable $e) { return false; }
		return $this->hasWatchdog();
	}

	public function botStatus() {
		$p = $this->paths();
		$s = $this->getSettings();
		$node = $this->findNode();
		$ver = '';
		if ($node) { $ver = trim((string)shell_exec(escapeshellarg($node) . ' -v 2>&1')); }
		$major = (int)ltrim($ver, 'v');
		$pid = $this->readPid($p['pid']);
		$running = $this->alive($pid, 'bot.js');
		$npmPid = $this->readPid($p['npmpid']);
		return [
			'running' => $running, 'pid' => $running ? $pid : 0,
			'uptime' => $running ? max(0, time() - (int)@filemtime($p['pid'])) : 0,
			'enabled' => $s['bot_enabled'] === '1',
			'node' => $node, 'node_version' => $ver, 'node_ok' => $major >= 18,
			'deps' => is_file($p['botdir'] . '/node_modules/discord.js/package.json'),
			'npm_running' => $this->alive($npmPid, 'npm'),
			'creds' => ($s['token'] !== '' && $s['client_id'] !== ''),
			'watchdog' => $this->hasWatchdog(),
		];
	}

	private function spawnBot() {
		$p = $this->paths();
		$st = $this->botStatus();
		if ($st['running']) { return ['ok' => true, 'message' => _('Bot is already running.')]; }
		if (!$st['node'] || !$st['node_ok']) { return ['ok' => false, 'message' => _('Node.js 18+ was not found on this server.')]; }
		if (!$st['deps']) { return ['ok' => false, 'message' => _('Bot dependencies are not installed. Click "Install dependencies".')]; }
		if (!$st['creds']) { return ['ok' => false, 'message' => _('Save the Client ID and Bot Token on the Settings tab first.')]; }

		if (is_file($p['log']) && filesize($p['log']) > 2 * 1024 * 1024) { @rename($p['log'], $p['log'] . '.1'); }
		@unlink($p['pid']);
		$setsid = is_executable('/usr/bin/setsid') ? '/usr/bin/setsid ' : '';
		$env = sprintf('DISCORDPROV_PIDFILE=%s FWCONSOLE=%s PATH=%s',
			escapeshellarg($p['pid']), escapeshellarg('/usr/sbin/fwconsole'), escapeshellarg('/usr/local/bin:/usr/bin:/bin:/usr/sbin:/sbin'));
		exec(sprintf('cd %s && %s nohup %s%s bot.js >> %s 2>&1 < /dev/null &',
			escapeshellarg($p['botdir']), $env, $setsid, escapeshellarg($st['node']), escapeshellarg($p['log'])));

		for ($i = 0; $i < 15; $i++) {
			usleep(300000);
			if ($this->botStatus()['running']) { return ['ok' => true, 'message' => _('Bot started.')]; }
		}
		return ['ok' => false, 'message' => _('The bot did not stay up. Check the log below.')];
	}

	private function withLock(callable $fn) {
		$fh = fopen($this->runDir() . '/discordprov.bot.lock', 'c');
		flock($fh, LOCK_EX);
		try { return $fn(); } finally { flock($fh, LOCK_UN); fclose($fh); }
	}

	public function botStart() {
		return $this->withLock(function () {
			$this->setConfig('bot_enabled', '1');
			$wd = $this->ensureWatchdog();
			$r = $this->spawnBot();
			if ($r['ok'] && !$wd) { $r['message'] .= ' ' . _('(Warning: could not install the auto-restart cron job.)'); }
			return $r;
		});
	}

	public function botStop($disable = true) {
		return $this->withLock(function () use ($disable) {
			if ($disable) { $this->setConfig('bot_enabled', '0'); }
			$p = $this->paths();
			$pid = $this->readPid($p['pid']);
			if ($this->alive($pid, 'bot.js')) {
				exec('kill -TERM ' . (int)$pid);
				for ($i = 0; $i < 20 && $this->alive($pid, 'bot.js'); $i++) { usleep(250000); }
				if ($this->alive($pid, 'bot.js')) { exec('kill -KILL ' . (int)$pid); usleep(300000); }
			}
			@unlink($p['pid']);
			return ['ok' => true, 'message' => $disable ? _('Bot stopped (auto-start disabled).') : _('Bot stopped.')];
		});
	}

	public function botRestart() {
		$this->botStop(false);
		return $this->botStart();
	}

	/** Run by cron every minute: start the bot if it should be up but isn't. */
	public function watchdog() {
		if ($this->getConfig('bot_enabled') !== '1') { return 'disabled'; }
		return $this->withLock(function () {
			$r = $this->spawnBot();
			return $r['ok'] ? 'ok' : $r['message'];
		});
	}

	public function npmInstall() {
		$p = $this->paths();
		$st = $this->botStatus();
		if ($st['npm_running']) { return ['ok' => true, 'message' => _('Installation is already running.')]; }
		$npm = $this->findNpm($st['node']);
		if (!$st['node'] || !$npm) { return ['ok' => false, 'message' => _('Node.js / npm was not found on this server.')]; }
		$home = $this->runDir();
		$env = sprintf('HOME=%s npm_config_cache=%s npm_config_update_notifier=false PATH=%s',
			escapeshellarg($home), escapeshellarg($home . '/discordprov-npm-cache'),
			escapeshellarg(dirname($st['node']) . ':/usr/local/bin:/usr/bin:/bin'));
		exec(sprintf('cd %s && %s nohup %s install --omit=dev --no-audit --no-fund > %s 2>&1 & echo $! > %s',
			escapeshellarg($p['botdir']), $env, escapeshellarg($npm), escapeshellarg($p['npmlog']), escapeshellarg($p['npmpid'])));
		return ['ok' => true, 'message' => _('Installing dependencies… watch the log below.')];
	}

	/* ===================================================== Discord API test */

	public function inviteUrl() {
		$id = $this->getConfig('client_id');
		if (!$id || !ctype_digit($id)) { return ''; }
		// permissions 19456 = View Channel + Send Messages + Embed Links
		return 'https://discord.com/oauth2/authorize?client_id=' . $id . '&scope=bot%20applications.commands&permissions=19456';
	}

	private function discord($path) {
		$ch = curl_init('https://discord.com/api/v10' . $path);
		curl_setopt_array($ch, [
			CURLOPT_RETURNTRANSFER => true, CURLOPT_TIMEOUT => 10,
			CURLOPT_HTTPHEADER => ['Authorization: Bot ' . $this->getConfig('token'), 'User-Agent: DiscordBot (freepbx-discordprov, 1.3)'],
		]);
		$body = curl_exec($ch);
		$code = (int)curl_getinfo($ch, CURLINFO_RESPONSE_CODE);
		curl_close($ch);
		return [$code, json_decode((string)$body, true)];
	}

	public function testConnection() {
		$s = $this->getSettings();
		$res = [];
		$add = function ($ok, $label, $detail = '') use (&$res) { $res[] = ['ok' => $ok, 'label' => $label, 'detail' => $detail]; };
		if ($s['token'] === '') { $add(false, 'Bot token', 'Not saved yet'); return $res; }
		if (!function_exists('curl_init')) { $add(false, 'PHP curl', 'The curl extension is missing'); return $res; }

		[$c, $me] = $this->discord('/users/@me');
		if ($c !== 200) { $add(false, 'Bot token', "Discord rejected the token (HTTP $c)"); return $res; }
		$add(true, 'Bot token', 'Logged in as ' . ($me['username'] ?? '?'));
		if ($s['client_id'] !== '' && ($me['id'] ?? '') !== $s['client_id']) {
			$add(false, 'Client ID', 'Does not match the bot (expected ' . ($me['id'] ?? '?') . ')');
		} else { $add(true, 'Client ID', 'Matches'); }

		$gid = $s['guild_id'];
		if ($gid === '') { $add(false, 'Server (Guild) ID', 'Not set - commands would register globally and take up to an hour'); }
		else {
			[$c, $g] = $this->discord('/guilds/' . $gid);
			$add($c === 200, 'Server', $c === 200 ? ($g['name'] ?? '') : 'Bot is not in that server - use the invite link first (HTTP ' . $c . ')');
		}
		foreach (['channel_id' => 'Panel channel', 'dir_channel_id' => 'Directory channel'] as $k => $label) {
			if ($s[$k] === '') { continue; }
			[$c, $ch] = $this->discord('/channels/' . $s[$k]);
			if ($c !== 200) { $add(false, $label, 'Not found or the bot cannot see it (HTTP ' . $c . ')'); }
			elseif ($gid !== '' && ($ch['guild_id'] ?? '') !== $gid) { $add(false, $label, 'That channel is in a different server'); }
			else { $add(true, $label, '#' . ($ch['name'] ?? '?')); }
		}
		if ($gid !== '') {
			$want = array_filter(array_unique(array_merge([$s['role_id'], $s['multi_role_id'], $s['any_role_id']], array_column($this->listCommands(), 'role_id'))));
			if ($want) {
				[$c, $roles] = $this->discord('/guilds/' . $gid . '/roles');
				if ($c === 200) {
					$have = array_column((array)$roles, 'name', 'id');
					foreach ($want as $rid) { $add(isset($have[$rid]), "Role $rid", isset($have[$rid]) ? '@' . $have[$rid] : 'Not found in this server'); }
				}
			}
		}
		return $res;
	}

	/* ========================================================== AJAX (GUI) */

	public function ajaxRequest($req, &$setting) {
		return in_array($req, ['botstatus', 'botlog', 'botstart', 'botstop', 'botrestart', 'npminstall', 'testconn', 'repost'], true);
	}

	public function ajaxHandler() {
		$cmd = $_REQUEST['command'] ?? '';
		$mutating = ['botstart', 'botstop', 'botrestart', 'npminstall', 'testconn', 'repost'];
		if (in_array($cmd, $mutating, true) && ($_SERVER['REQUEST_METHOD'] ?? '') !== 'POST') {
			return ['ok' => false, 'message' => 'POST required'];
		}
		switch ($cmd) {
			case 'botstatus': return ['ok' => true] + $this->botStatus();
			case 'botlog':
				$p = $this->paths();
				return ['ok' => true, 'log' => $this->tail(($_REQUEST['which'] ?? '') === 'npm' ? $p['npmlog'] : $p['log'])];
			case 'botstart': return $this->botStart();
			case 'botstop': return $this->botStop(true);
			case 'botrestart': return $this->botRestart();
			case 'npminstall': return $this->npmInstall();
			case 'testconn': return ['ok' => true, 'checks' => $this->testConnection()];
			case 'repost':
				$k = (($_POST['target'] ?? '') === 'directory') ? 'dir_message_id' : 'panel_message_id';
				$this->setConfig($k, '');
				return $this->botRestart();
		}
		return ['ok' => false, 'message' => 'Unknown command'];
	}
}
