'use strict';
// SPDX-License-Identifier: GPL-3.0-or-later
const { execFile } = require('child_process');
const {
  Client, GatewayIntentBits, EmbedBuilder, ActionRowBuilder, ButtonBuilder,
  ButtonStyle, MessageFlags, Events, REST, Routes,
  ModalBuilder, TextInputBuilder, TextInputStyle, StringSelectMenuBuilder,
} = require('discord.js');

const FWCONSOLE = process.env.FWCONSOLE || '/usr/sbin/fwconsole';
const EPHEMERAL = MessageFlags.Ephemeral;
const fs = require('fs');
const sleep = (ms) => new Promise((r) => setTimeout(r, ms));

// Timestamped logging (the GUI tails this file).
for (const lvl of ['log', 'error']) {
  const orig = console[lvl].bind(console);
  console[lvl] = (...a) => orig(new Date().toISOString(), lvl === 'error' ? 'ERROR' : 'INFO ', ...a);
}

// The FreePBX module tracks the process through this pidfile.
const PIDFILE = process.env.DISCORDPROV_PIDFILE;
if (PIDFILE) {
  try { fs.writeFileSync(PIDFILE, String(process.pid)); } catch (e) { console.error('Cannot write pidfile:', e.message); }
}
function shutdown(code) {
  try { if (PIDFILE) fs.unlinkSync(PIDFILE); } catch (_) { /* already gone */ }
  process.exit(code);
}
process.on('SIGTERM', () => { console.log('Stopping (SIGTERM)'); shutdown(0); });
process.on('SIGINT', () => shutdown(0));
process.on('uncaughtException', (e) => { console.error('Uncaught:', e); shutdown(1); });
process.on('unhandledRejection', (e) => { console.error('Unhandled rejection:', e); });

// Config and command list are loaded once at start; saving settings in the GUI
// restarts the bot, so this cache is always current.
// (fwconsole takes ~1s to boot, so it must never run before we ack an interaction.)
const state = { cfg: null, commands: [], dirHash: '' };
const cooldown = new Map();

function fw(...args) {
  return new Promise((resolve, reject) => {
    execFile(FWCONSOLE, ['discordprov', ...args.map(String)], { timeout: 90000 }, (err, stdout) => {
      const last = String(stdout || '').trim().split('\n').pop();
      try { resolve(JSON.parse(last)); } catch (e) { reject(err || new Error('Bad output: ' + last)); }
    });
  });
}

function hasRole(member, roleId) {
  const roles = member?.roles;
  if (!roles) return false;
  return roles.cache ? roles.cache.has(roleId) : Array.isArray(roles) && roles.includes(roleId);
}

function tooFast(userId, ms) {
  const now = Date.now();
  if ((cooldown.get(userId) || 0) > now) return true;
  cooldown.set(userId, now + ms);
  return false;
}

/* ------------------------------------------------------------ provisioning panel */

function panelPayload() {
  const embed = new EmbedBuilder()
    .setTitle('📞 Get a Phone Extension')
    .setDescription('Click a button to manage your personal SIP extension.\nYour credentials are sent **only to you** and are never posted in the channel.')
    .setColor(0x5865f2);
  const row = new ActionRowBuilder().addComponents(
    new ButtonBuilder().setCustomId('dp_create').setLabel('Create Extension').setStyle(ButtonStyle.Success),
    new ButtonBuilder().setCustomId('dp_reset').setLabel('Reset Password').setStyle(ButtonStyle.Primary),
    new ButtonBuilder().setCustomId('dp_delete').setLabel('Delete Extension').setStyle(ButtonStyle.Danger),
  );
  return { embeds: [embed], components: [row] };
}

const support = () => (state.cfg && state.cfg.support_note) || 'For anything else, please open a support ticket by DMing.';

function credsEmbed(r, title) {
  const e = new EmbedBuilder().setTitle(title).setColor(0x57f287)
    .setDescription('⏳ **Please wait 60 seconds before registering** - the PBX is reloading.')
    .addFields(
      { name: 'Extension / Username', value: '`' + r.extension + '`', inline: true },
      { name: 'Password', value: '||`' + r.secret + '`||', inline: true },
      { name: 'Server', value: '`' + r.host + ':' + r.port + '`' },
    );
  if (r.voicemail && r.voicemail.mode === 'ext') {
    e.addFields({ name: 'Voicemail', value: 'Your voicemail PIN is your extension number. Manage your voicemail by dialing **\\*97** or **6245**.' });
  } else if (r.voicemail && r.voicemail.mode === 'random') {
    e.addFields({ name: 'Voicemail PIN', value: '||`' + r.voicemail.pin + '`||\nManage your voicemail by dialing **\\*97** or **6245**.' });
  }
  e.addFields({ name: 'Need anything else?', value: support() });
  return e.setFooter({ text: 'Only you can see this message.' });
}

const ERR = {
  exists: (r) => `You already have extension **${r.extension}**. Use *Reset Password* if you lost the password.`,
  none: () => 'You do not have an extension yet.',
  range_full: () => `No free extensions are available. ${support()}`,
  create_failed: () => `The PBX could not create the extension. ${support()}`,
  limit: (r) => `You already have the maximum of ${r.max} extensions (${(r.extensions || []).join(', ')}).`,
  not_owner: () => 'That extension is not yours.',
  choose: () => 'Please choose which extension.',
  linked: () => 'This extension was linked by an admin, so its password can only be changed in FreePBX.',
  bad_ext: () => 'That is not a valid extension number.',
  out_of_range: (r) => `Please choose an extension inside: ${r.ranges}`,
  taken: (r) => `That extension is already in use.${r.next ? ` The next free one is **${r.next}**.` : ''}`,
};

const errText = (r) => (ERR[r.error] || (() => r.message || 'Something went wrong.'))(r);
const isAny = (i) => !!(state.cfg.any_role_id && hasRole(i.member, state.cfg.any_role_id));
const isMulti = (i) => !!(state.cfg.multi_role_id && hasRole(i.member, state.cfg.multi_role_id));

async function provisionFlow(i, want, multi, any) {
  await i.deferReply({ flags: EPHEMERAL });
  const r = await fw('provision', i.user.id, i.user.username, want || '', multi ? '1' : '0', any ? '1' : '0');
  if (r.ok) return i.editReply({ embeds: [credsEmbed(r, '✅ Extension created')] });
  if (r.error === 'create_failed') console.error('Create failed:', r.detail);
  if (r.error === 'exception') console.error('Provision exception:', r.message);
  return i.editReply({ content: errText(r) });
}

function extModal(any) {
  return new ModalBuilder().setCustomId('dp_create_modal').setTitle('Choose your extension').addComponents(
    new ActionRowBuilder().addComponents(
      new TextInputBuilder().setCustomId('ext').setLabel('Extension number (blank = next free)')
        .setStyle(TextInputStyle.Short).setRequired(false).setMaxLength(10)
        .setPlaceholder(any ? 'Any free number' : String(state.cfg.ext_ranges || '').slice(0, 100))));
}

async function handleModal(i) {
  const cfg = state.cfg;
  if (cfg.role_id && !hasRole(i.member, cfg.role_id)) {
    return i.reply({ content: 'You do not have the required role.', flags: EPHEMERAL });
  }
  if (tooFast(i.user.id, 8000)) return i.reply({ content: 'Slow down - try again in a few seconds.', flags: EPHEMERAL });
  return provisionFlow(i, i.fields.getTextInputValue('ext').trim(), isMulti(i), isAny(i));
}

const confirmRow = (ext) => new ActionRowBuilder().addComponents(
  new ButtonBuilder().setCustomId('dp_delete_confirm:' + ext).setLabel('Yes, continue').setStyle(ButtonStyle.Danger));

function pickRow(kind, st) {
  return new ActionRowBuilder().addComponents(
    new StringSelectMenuBuilder().setCustomId('dp_pick_' + kind).setPlaceholder('Choose an extension')
      .addOptions(st.extensions.slice(0, 25).map((e) => ({ label: e, value: e, description: st.linked && st.linked[e] ? 'Linked (existing)' : undefined }))));
}

// The interaction is already deferred when this runs, so every reply is an editReply.
async function actOn(i, kind, ext, st) {
  if (kind === 'reset') {
    const r = await fw('reset', i.user.id, ext);
    if (r.ok) return i.editReply({ content: '', embeds: [credsEmbed(r, '🔑 Password reset')], components: [] });
    return i.editReply({ content: errText(r), embeds: [], components: [] });
  }
  const linked = st && st.linked && st.linked[ext];
  const text = linked
    ? `This removes your link to extension **${ext}**. The extension itself stays on the PBX. Sure?`
    : `This permanently deletes extension **${ext}**. Sure?`;
  return i.editReply({ content: text, embeds: [], components: [confirmRow(ext)] });
}

async function handleButton(i) {
  const cfg = state.cfg;
  if (cfg.role_id && !hasRole(i.member, cfg.role_id)) {
    return i.reply({ content: 'You do not have the required role.', flags: EPHEMERAL });
  }
  if (i.customId === 'dp_create' && cfg.ext_mode === 'ask') return i.showModal(extModal(isAny(i)));

  // The confirm click follows our own prompt, so it must not hit the cooldown that the prompt started.
  const confirm = i.customId.startsWith('dp_delete_confirm:');
  if (!confirm && tooFast(i.user.id, 8000)) {
    return i.reply({ content: 'Slow down - try again in a few seconds.', flags: EPHEMERAL });
  }
  if (i.customId === 'dp_create') return provisionFlow(i, '', isMulti(i), isAny(i));

  if (confirm) {
    await i.deferUpdate();
    const r = await fw('remove', i.user.id, i.customId.split(':')[1]);
    let content = errText(r);
    if (r.ok) {
      content = r.unlinked
        ? `Unlinked from extension **${r.extension}**. It still exists on the PBX; only an admin can delete it.`
        : `Extension **${r.extension}** deleted.`;
    }
    return i.editReply({ content, embeds: [], components: [] });
  }

  if (i.customId === 'dp_reset' || i.customId === 'dp_delete') {
    await i.deferReply({ flags: EPHEMERAL });
    const kind = i.customId === 'dp_reset' ? 'reset' : 'delete';
    const st = await fw('status', i.user.id);
    if (!st.ok) return i.editReply({ content: errText(st) });
    if (st.extensions.length > 1) {
      return i.editReply({ content: `You have ${st.extensions.length} extensions. Which one?`, components: [pickRow(kind, st)] });
    }
    return actOn(i, kind, st.extensions[0], st);
  }
}

async function handlePick(i) {
  const cfg = state.cfg;
  if (cfg.role_id && !hasRole(i.member, cfg.role_id)) {
    return i.reply({ content: 'You do not have the required role.', flags: EPHEMERAL });
  }
  await i.deferUpdate();
  const kind = i.customId === 'dp_pick_reset' ? 'reset' : 'delete';
  const st = await fw('status', i.user.id);
  return actOn(i, kind, i.values[0], st);
}

async function ensurePanel(client) {
  const cfg = state.cfg;
  if (!cfg.channel_id) return;
  const channel = await client.channels.fetch(cfg.channel_id);
  if (cfg.panel_message_id) {
    try { await (await channel.messages.fetch(cfg.panel_message_id)).edit(panelPayload()); return; } catch (_) { /* repost */ }
  }
  const sent = await channel.send(panelPayload());
  cfg.panel_message_id = sent.id;
  await fw('set', 'panel_message_id', sent.id);
}

/* --------------------------------------------------------------- slash commands */

async function registerCommands() {
  const { cfg, commands } = state;
  const body = commands.map((c) => ({
    name: c.name,
    description: c.description,
    options: c.options.map((o) => ({
      type: o.type === 'user' ? 6 : 3, // 6 = USER, 3 = STRING
      name: o.name, description: o.description, required: !!o.required,
      ...(o.type !== 'user' && o.choices && o.choices.length ? { choices: o.choices.map((v) => ({ name: v, value: v })) } : {}),
    })),
  }));
  const rest = new REST({ version: '10' }).setToken(cfg.token);
  const route = cfg.guild_id
    ? Routes.applicationGuildCommands(cfg.client_id, cfg.guild_id)
    : Routes.applicationCommands(cfg.client_id);
  await rest.put(route, { body });
  console.log(`Registered ${body.length} slash command(s)`);
}

async function handleCommand(i) {
  const cmd = state.commands.find((c) => c.name === i.commandName);
  if (!cmd) return i.reply({ content: 'Unknown command.', flags: EPHEMERAL });
  if (cmd.admin && !cmd.role_id) return i.reply({ content: 'This command is disabled until a required role is set.', flags: EPHEMERAL });
  if (cmd.role_id && !hasRole(i.member, cmd.role_id)) return i.reply({ content: 'You do not have the required role.', flags: EPHEMERAL });
  if (tooFast(i.user.id, 3000)) return i.reply({ content: 'Slow down a moment.', flags: EPHEMERAL });

  await i.deferReply(cmd.ephemeral ? { flags: EPHEMERAL } : {});
  const opts = {};
  for (const o of cmd.options) {
    if (o.type === 'user') {
      const u = i.options.getUser(o.name);
      if (u) { opts[o.name] = u.id; opts[o.name + '_name'] = u.username; }
    } else {
      const v = i.options.getString(o.name);
      if (v !== null) opts[o.name] = v;
    }
  }
  const r = await fw('run', cmd.name, i.user.id, JSON.stringify(opts));
  if (!r.ok) return i.editReply({ content: r.message || 'Command failed.' });
  const embed = new EmbedBuilder().setTitle(String(r.title).slice(0, 250))
    .setDescription(r.lines.join('\n').slice(0, 4000)).setColor(0x5865f2);
  return i.editReply({ embeds: [embed] });
}

/* --------------------------------------------------------------- live directory */

function buildDirectoryEmbeds(rows, cfg) {
  const online = rows.filter((r) => r.online).length;
  const dnd = rows.filter((r) => r.dnd).length;
  const lines = rows.map((r) => {
    const icon = r.online === null ? '⚪' : (r.dnd ? '🔴' : (r.online ? '🟢' : '⚫'));
    const who = r.discord_id ? ` - <@${r.discord_id}>` : '';
    return `${icon} **${r.ext}** · ${r.name}${who}`;
  });
  const chunks = []; let cur = '';
  for (const l of lines) {
    if ((cur + l + '\n').length > 3800) { chunks.push(cur); cur = ''; }
    cur += l + '\n';
  }
  if (cur) chunks.push(cur);
  if (!chunks.length) chunks.push('_No extensions to show._');

  const shown = chunks.slice(0, 10);
  const embeds = shown.map((text, idx) => {
    const e = new EmbedBuilder().setColor(0x5865f2).setDescription(text);
    if (idx === 0) e.setTitle('📒 Live Directory').addFields({ name: 'Summary', value: `🟢 ${online} online · 🔴 ${dnd} DND · ${rows.length} total` });
    if (idx === shown.length - 1) e.setFooter({ text: `🟢 online  ⚫ offline  🔴 DND  ⚪ unknown • refreshes every ${cfg.dir_interval}s` });
    return e;
  });
  return embeds;
}

async function updateDirectory(client) {
  const cfg = state.cfg;
  if (!cfg.dir_channel_id) return;
  const r = await fw('directory');
  if (!r.ok) return;
  const hash = JSON.stringify(r.rows);
  if (hash === state.dirHash && cfg.dir_message_id) return; // nothing changed: no API call
  const payload = { embeds: buildDirectoryEmbeds(r.rows, cfg) };
  const channel = await client.channels.fetch(cfg.dir_channel_id);
  let done = false;
  if (cfg.dir_message_id) {
    try { await (await channel.messages.fetch(cfg.dir_message_id)).edit(payload); done = true; } catch (_) { /* repost */ }
  }
  if (!done) {
    const sent = await channel.send(payload);
    cfg.dir_message_id = sent.id;
    await fw('set', 'dir_message_id', sent.id);
  }
  state.dirHash = hash;
}

/* ------------------------------------------------------------------------ main */

async function main() {
  state.cfg = await fw('config');
  while (!state.cfg.token || !state.cfg.client_id) {
    console.log('Token / Client ID not configured yet; waiting...');
    await sleep(15000);
    state.cfg = await fw('config');
  }
  state.commands = (await fw('commands')).commands || [];

  const client = new Client({ intents: [GatewayIntentBits.Guilds], allowedMentions: { parse: [] } });

  client.once(Events.ClientReady, async (c) => {
    console.log(`Logged in as ${c.user.tag}`);
    try { await registerCommands(); } catch (e) { console.error('Command registration failed:', e.message); }
    try { await ensurePanel(client); } catch (e) { console.error('Panel error:', e.message); }
    const tick = () => updateDirectory(client).catch((e) => console.error('Directory error:', e.message));
    tick();
    setInterval(tick, Math.max(30, parseInt(state.cfg.dir_interval, 10) || 60) * 1000);
  });

  client.on(Events.InteractionCreate, async (i) => {
    try {
      if (i.isButton() && i.customId.startsWith('dp_')) return await handleButton(i);
      if (i.isStringSelectMenu() && i.customId.startsWith('dp_pick_')) return await handlePick(i);
      if (i.isModalSubmit() && i.customId === 'dp_create_modal') return await handleModal(i);
      if (i.isChatInputCommand()) return await handleCommand(i);
    } catch (e) {
      console.error(e);
      const msg = { content: `Something went wrong. ${support()}`, flags: EPHEMERAL };
      if (i.deferred || i.replied) i.editReply(msg).catch(() => {}); else i.reply(msg).catch(() => {});
    }
  });

  await client.login(state.cfg.token);
}

main().catch((e) => { console.error(e); shutdown(1); });
