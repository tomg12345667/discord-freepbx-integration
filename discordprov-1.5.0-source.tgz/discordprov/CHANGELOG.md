# Changelog

## 1.5.0
- New extensions get **max contacts = 50** (configurable, 1-200).
- New extensions get **voicemail enabled**. PIN options: the extension number (default), a random 6-digit PIN shown in the private reply, or disabled.

## 1.4.0
- **Multiple extensions per user, restricted.** By default one user = one extension. A **Role ID** and/or an **allowed-user list** (Settings) may hold several, up to a configurable maximum.
- Reset Password / Delete show an extension picker when the user owns several. `/mystatus`, `/dnd`, `/forward` and `/call` take an optional `extension` option; `/unlink` can target one extension.
- Admin links (`/link`, Users & Links tab) are not limited by the one-extension rule.
- Fix: the Delete confirmation button could be blocked by the cooldown started by the Delete click.
- Existing assignments migrate automatically on upgrade.

## 1.3.0
- **Extension ranges:** one or more ranges (e.g. `7000-7099, 7200-7299`); assignment is lowest-free, going up. Numbers used by other FreePBX objects are skipped.
- **Ask-the-user mode:** a Discord popup lets users request an extension; validated against the ranges, with the next free number suggested if taken.
- **Caller ID** / extension name is now just the Discord username (no "Discord" prefix); click-to-call uses the same name.
- **Linking:** `/link` and `/unlink` (admin, ship disabled) and a new **Users & Links** tab connect existing PBX extensions to Discord users.
- Linked extensions are never deleted or password-reset through Discord (the Delete button only unlinks).
- The bot never pings users from its replies.
- Old single start/end settings migrate to the ranges field on upgrade.

## 1.2.1
- Fix: extension creation crashed in FreePBX 17 (`Undefined array key "vm"` from the Voicemail Quick Create hook).
- Failed creations are rolled back and the real error is written to the bot log.
- `fwconsole discordprov` always returns JSON, even when PHP throws.

## 1.2.0
- Everything managed from the WebUI: **Bot** tab (Start/Stop/Restart, live log, checklist, dependency installer, connection test, invite link).
- Cron watchdog replaces systemd; saving settings restarts the bot automatically.
- Release workflow bundles bot dependencies so the module installs from Module Admin.

## 1.1.0
- FreePBX 17 only. Custom slash commands, Live Directory, acknowledge-before-work fix.

## 1.0.0
- Initial release.
