<?php
$h = fn($v) => htmlspecialchars((string)$v, ENT_QUOTES, 'UTF-8');
$tab = fn($v, $label) => '<li role="presentation"' . ($view === $v ? ' class="active"' : '') . '><a href="?display=discordprov&view=' . $v . '">' . $label . '</a></li>';
?>
<div class="container-fluid">
	<h1><?php echo _('Discord Provisioner') ?></h1>
	<ul class="nav nav-tabs" style="margin-bottom:15px">
		<?php echo $tab('bot', _('Bot')), $tab('settings', _('Settings & Directory')), $tab('users', _('Users & Links')), $tab('commands', _('Commands')); ?>
	</ul>
	<?php if ($msg): ?><div class="alert alert-<?php echo $h($msgClass) ?>"><?php echo $h($msg) ?></div><?php endif; ?>

<?php if ($view === 'bot'): ?>
	<div class="row">
	<div class="col-md-5">
		<div class="panel panel-default"><div class="panel-heading"><b><?php echo _('Bot status') ?></b></div>
		<div class="panel-body">
			<p><span id="dp-badge" class="label label-default">…</span> <span id="dp-meta" class="text-muted"></span></p>
			<button class="btn btn-success" data-cmd="botstart"><?php echo _('Start') ?></button>
			<button class="btn btn-warning" data-cmd="botrestart"><?php echo _('Restart') ?></button>
			<button class="btn btn-danger" data-cmd="botstop"><?php echo _('Stop') ?></button>
			<div id="dp-actionmsg" style="margin-top:10px"></div>
			<p class="help-block"><?php echo _('Start enables auto-start: a cron watchdog (every minute) brings the bot back after crashes and reboots. Stop disables it.') ?></p>
		</div></div>

		<div class="panel panel-default"><div class="panel-heading"><b><?php echo _('Setup checklist') ?></b></div>
		<table class="table" style="margin:0">
			<tr><td><?php echo _('Node.js 18+') ?></td><td id="chk-node"></td></tr>
			<tr><td><?php echo _('Bot dependencies') ?></td><td><span id="chk-deps"></span>
				<button class="btn btn-xs btn-default" id="dp-npm"><?php echo _('Install dependencies') ?></button></td></tr>
			<tr><td><?php echo _('Credentials saved') ?></td><td id="chk-creds"></td></tr>
			<tr><td><?php echo _('Auto-restart watchdog') ?></td><td id="chk-wd"></td></tr>
			<tr><td><?php echo _('Invite bot to server') ?></td><td>
				<?php if ($invite): ?><a href="<?php echo $h($invite) ?>" target="_blank" rel="noopener"><?php echo _('Open invite link') ?> ↗</a>
				<?php else: ?><span class="text-muted"><?php echo _('Save the Client ID first') ?></span><?php endif; ?></td></tr>
			<tr><td><?php echo _('Discord connection') ?></td><td><button class="btn btn-xs btn-default" id="dp-test"><?php echo _('Test connection') ?></button></td></tr>
		</table></div>
		<div id="dp-testout"></div>

		<?php if (!$s['token']): ?>
		<div class="alert alert-info">
			<b><?php echo _('First time?') ?></b>
			<ol style="padding-left:18px;margin:5px 0 0">
				<li><?php echo _('Create an application at discord.com/developers → add a Bot → copy the Token.') ?></li>
				<li><?php echo _('Enter Client ID, Token, Server ID and channel IDs on the Settings tab and save.') ?></li>
				<li><?php echo _('Use the invite link above, install dependencies (if needed), then press Start.') ?></li>
			</ol>
		</div>
		<?php endif; ?>
	</div>

	<div class="col-md-7">
		<div class="panel panel-default"><div class="panel-heading">
			<b><?php echo _('Log') ?></b>
			<select id="dp-logwhich" class="input-sm" style="margin-left:10px">
				<option value="bot"><?php echo _('Bot') ?></option><option value="npm"><?php echo _('Dependency install') ?></option>
			</select>
			<label style="margin-left:10px;font-weight:normal"><input type="checkbox" id="dp-pause"> <?php echo _('Pause') ?></label>
			<span class="pull-right">
				<button class="btn btn-xs btn-default" id="dp-rp-panel"><?php echo _('Re-post panel') ?></button>
				<button class="btn btn-xs btn-default" id="dp-rp-dir"><?php echo _('Re-post directory') ?></button>
			</span>
		</div>
		<pre id="dp-log" style="margin:0;border:0;border-radius:0;height:520px;overflow:auto;font-size:11px"></pre></div>
	</div>
	</div>

	<script>
	(function ($) {
		function call(cmd, data, cb) {
			$.ajax({ url: 'ajax.php', method: 'POST', dataType: 'json', data: $.extend({ module: 'discordprov', command: cmd }, data || {}) })
				.done(function (r) { cb((r && r.ok !== undefined) ? r : ((r && r.data) || r || {})); })
				.fail(function () { cb({ ok: false, message: 'Request failed' }); });
		}
		function mark(sel, ok, text) {
			$(sel).empty().append($('<span>').addClass(ok ? 'text-success' : 'text-danger').text(ok ? '✔ ' : '✖ ')).append(document.createTextNode(text || ''));
		}
		function uptime(s) { var d = Math.floor(s / 86400), h = Math.floor(s % 86400 / 3600), m = Math.floor(s % 3600 / 60); return (d ? d + 'd ' : '') + (h ? h + 'h ' : '') + m + 'm'; }
		function render(d) {
			if (d.running === undefined) { return; }
			$('#dp-badge').attr('class', 'label label-' + (d.running ? 'success' : (d.enabled ? 'warning' : 'default')))
				.text(d.running ? 'Running' : (d.enabled ? 'Starting / waiting for watchdog' : 'Stopped'));
			$('#dp-meta').text(d.running ? 'PID ' + d.pid + ' · up ' + uptime(d.uptime) : '');
			mark('#chk-node', d.node_ok, d.node ? d.node_version : 'not found');
			mark('#chk-deps', d.deps, d.deps ? 'installed' : (d.npm_running ? 'installing…' : 'missing'));
			$('#dp-npm').toggle(!d.deps).prop('disabled', !!d.npm_running);
			mark('#chk-creds', d.creds, d.creds ? 'saved' : 'missing');
			mark('#chk-wd', d.watchdog, d.watchdog ? 'installed' : 'installed on first Start');
		}
		function poll() {
			call('botstatus', {}, render);
			call('botlog', { which: $('#dp-logwhich').val() }, function (r) {
				if ($('#dp-pause').is(':checked')) { return; }
				var el = $('#dp-log'), bottom = el[0].scrollHeight - el.scrollTop() - el.innerHeight() < 40;
				el.text(r.log || '(empty)');
				if (bottom) { el.scrollTop(el[0].scrollHeight); }
			});
		}
		function action(btn, cmd, data) {
			btn.prop('disabled', true);
			call(cmd, data, function (r) {
				$('#dp-actionmsg').attr('class', 'alert alert-' + (r.ok ? 'success' : 'danger')).text(r.message || '');
				btn.prop('disabled', false); poll();
			});
		}
		$('[data-cmd]').on('click', function () { action($(this), $(this).data('cmd')); });
		$('#dp-npm').on('click', function () { $('#dp-logwhich').val('npm'); action($(this), 'npminstall'); });
		$('#dp-rp-panel').on('click', function () { action($(this), 'repost', { target: 'panel' }); });
		$('#dp-rp-dir').on('click', function () { action($(this), 'repost', { target: 'directory' }); });
		$('#dp-test').on('click', function () {
			var b = $(this).prop('disabled', true), out = $('#dp-testout').empty().append($('<p>').text('Testing…'));
			call('testconn', {}, function (r) {
				out.empty();
				$.each(r.checks || [], function (_, c) {
					out.append($('<div>').addClass('alert alert-' + (c.ok ? 'success' : 'danger')).css('padding', '6px 10px').css('margin-bottom', '4px')
						.append($('<b>').text(c.label + ': ')).append(document.createTextNode(c.detail)));
				});
				if (!r.checks) { out.text(r.message || 'Failed'); }
				b.prop('disabled', false);
			});
		});
		$('#dp-logwhich').on('change', poll);
		render(<?php echo json_encode($bot ?: new stdClass, JSON_HEX_TAG | JSON_HEX_AMP) ?>);
		poll(); setInterval(poll, 3000);
	})(jQuery);
	</script>

<?php elseif ($view === 'settings'): ?>
	<form method="post" action="?display=discordprov&view=settings">
		<input type="hidden" name="action" value="save">
		<h3><?php echo _('Bot') ?></h3>
		<?php
		$fields = [
			['client_id', 'Application (Client) ID', 'text'],
			['token', 'Bot Token' . ($s['token'] ? ' (saved — leave blank to keep)' : ''), 'password'],
			['guild_id', 'Server (Guild) ID — commands register here instantly', 'text'],
			['channel_id', 'Provisioning panel channel ID', 'text'],
			['role_id', 'Role ID required to use the panel buttons (optional)', 'text'],
			['multi_role_id', 'Role ID allowed to have MULTIPLE extensions (everyone else gets one)', 'text'],
			['multi_user_ids', 'Discord user IDs also allowed multiple extensions (comma-separated)', 'text'],
			['multi_max', 'Maximum extensions for those users', 'number'],
			['ext_ranges', 'Extension range(s) — e.g. 7000-7099, 7200-7299 (assigned lowest-free, going up)', 'text'],
		];
		foreach ($fields as [$k, $label, $type]): ?>
		<div class="form-group">
			<label for="<?php echo $k ?>"><?php echo $h($label) ?></label>
			<input class="form-control" type="<?php echo $type ?>" id="<?php echo $k ?>" name="<?php echo $k ?>"
				value="<?php echo $k === 'token' ? '' : $h($s[$k]) ?>" autocomplete="off">
		</div>
		<?php endforeach; ?>
		<div class="form-group">
			<label for="ext_mode"><?php echo _('How is the extension chosen?') ?></label>
			<select class="form-control" id="ext_mode" name="ext_mode">
				<option value="auto" <?php echo $s['ext_mode'] !== 'ask' ? 'selected' : '' ?>><?php echo _('Automatic — next free number in the range(s)') ?></option>
				<option value="ask" <?php echo $s['ext_mode'] === 'ask' ? 'selected' : '' ?>><?php echo _('Ask the user — popup for their preferred number (blank = next free)') ?></option>
			</select>
		</div>
		<?php
		foreach ([['sip_host', 'SIP server hostname shown to users', 'text'], ['sip_port', 'SIP port shown to users', 'number'], ['max_contacts', 'Max contacts (devices registered at once) per new extension', 'number']] as [$k, $label, $type]): ?>
		<div class="form-group">
			<label for="<?php echo $k ?>"><?php echo $h($label) ?></label>
			<input class="form-control" type="<?php echo $type ?>" id="<?php echo $k ?>" name="<?php echo $k ?>" value="<?php echo $h($s[$k]) ?>" autocomplete="off">
		</div>
		<?php endforeach; ?>
		<div class="form-group">
			<label for="vm_mode"><?php echo _('Voicemail for new extensions') ?></label>
			<select class="form-control" id="vm_mode" name="vm_mode">
				<option value="ext" <?php echo $s['vm_mode'] === 'ext' ? 'selected' : '' ?>><?php echo _('Enabled — PIN is the extension number (easy to guess)') ?></option>
				<option value="random" <?php echo $s['vm_mode'] === 'random' ? 'selected' : '' ?>><?php echo _('Enabled — random 6-digit PIN shown to the user') ?></option>
				<option value="off" <?php echo $s['vm_mode'] === 'off' ? 'selected' : '' ?>><?php echo _('Disabled') ?></option>
			</select>
		</div>
		<div class="checkbox"><label><input type="checkbox" name="auto_reload" <?php echo $s['auto_reload'] === '1' ? 'checked' : '' ?>> <?php echo _('Run fwconsole reload automatically after provisioning changes') ?></label></div>
		<div class="checkbox"><label><input type="checkbox" name="repost"> <?php echo _('Re-post the provisioning panel on save') ?></label></div>

		<h3><?php echo _('Live Directory') ?></h3>
		<div class="form-group">
			<label for="dir_channel_id"><?php echo _('Directory channel ID (blank = disabled)') ?></label>
			<input class="form-control" id="dir_channel_id" name="dir_channel_id" value="<?php echo $h($s['dir_channel_id']) ?>" autocomplete="off">
		</div>
		<div class="form-group">
			<label for="dir_source"><?php echo _('Who is listed') ?></label>
			<select class="form-control" id="dir_source" name="dir_source">
				<option value="discord" <?php echo $s['dir_source'] === 'discord' ? 'selected' : '' ?>><?php echo _('Only extensions linked to Discord users') ?></option>
				<option value="all" <?php echo $s['dir_source'] === 'all' ? 'selected' : '' ?>><?php echo _('All PBX extensions') ?></option>
			</select>
		</div>
		<div class="form-group">
			<label for="dir_interval"><?php echo _('Refresh interval (seconds, 30-3600)') ?></label>
			<input class="form-control" type="number" id="dir_interval" name="dir_interval" value="<?php echo $h($s['dir_interval']) ?>">
		</div>
		<div class="checkbox"><label><input type="checkbox" name="dir_mentions" <?php echo $s['dir_mentions'] === '1' ? 'checked' : '' ?>> <?php echo _('Show the owner\'s Discord mention next to their extension') ?></label></div>
		<div class="checkbox"><label><input type="checkbox" name="repost_dir"> <?php echo _('Re-post the directory message on save') ?></label></div>

		<p class="help-block"><?php echo _('Saving restarts the bot automatically if it is running.') ?></p>
		<button type="submit" class="btn btn-primary"><?php echo _('Save') ?></button>
	</form>

<?php elseif ($view === 'users'): ?>
	<h3><?php echo _('Link an existing extension') ?></h3>
	<p class="help-block"><?php echo _('Connect an extension that already exists on the PBX to a Discord user. Linked extensions are never deleted or password-reset by the bot. Tip: in Discord enable Developer Mode, right-click the user → Copy User ID. Admins can also use the /link command in Discord. Admin links are not limited by the one-extension rule, so a user can be linked to several.') ?></p>
	<form method="post" class="form-inline" action="?display=discordprov&view=users" style="margin-bottom:20px">
		<input type="hidden" name="action" value="link_save">
		<div class="form-group"><label for="link_discord_id"><?php echo _('Discord user ID') ?></label>
			<input class="form-control" id="link_discord_id" name="link_discord_id" placeholder="123456789012345678" autocomplete="off" size="24"></div>
		<div class="form-group"><label for="link_ext"><?php echo _('Extension') ?></label>
			<select class="form-control" id="link_ext" name="link_ext">
				<?php foreach ($pbx_exts as $x): ?>
				<option value="<?php echo $h($x['extension']) ?>"><?php echo $h($x['extension'] . ' — ' . $x['name']) ?></option>
				<?php endforeach; if (!$pbx_exts): ?><option value=""><?php echo _('(no unlinked extensions)') ?></option><?php endif; ?>
			</select></div>
		<button type="submit" class="btn btn-primary"><?php echo _('Link') ?></button>
	</form>

	<h3><?php echo _('Linked & provisioned users') ?></h3>
	<table class="table table-striped">
		<thead><tr><th><?php echo _('Discord') ?></th><th><?php echo _('Extension') ?></th><th><?php echo _('Type') ?></th><th></th></tr></thead>
		<tbody>
		<?php foreach ($owners as $ext => $did): $isLinked = isset($linked[$ext]); ?>
			<tr>
				<td><?php echo $h($names[$did] ?? '—') ?><br><small class="text-muted"><?php echo $h($did) ?></small></td>
				<td><?php echo $h($ext) ?></td>
				<td><?php echo $isLinked ? _('Linked (existing)') : _('Provisioned by bot') ?></td>
				<td style="white-space:nowrap">
					<form method="post" action="?display=discordprov&view=users" style="display:inline" onsubmit="return confirm('Unlink extension <?php echo $h($ext) ?>? The extension stays on the PBX.')">
						<input type="hidden" name="action" value="user_unlink"><input type="hidden" name="discord_id" value="<?php echo $h($did) ?>"><input type="hidden" name="ext" value="<?php echo $h($ext) ?>">
						<button class="btn btn-xs btn-default"><?php echo _('Unlink') ?></button>
					</form>
					<?php if (!$isLinked): ?>
					<form method="post" action="?display=discordprov&view=users" style="display:inline" onsubmit="return confirm('DELETE extension <?php echo $h($ext) ?> from the PBX?')">
						<input type="hidden" name="action" value="user_delete"><input type="hidden" name="discord_id" value="<?php echo $h($did) ?>"><input type="hidden" name="ext" value="<?php echo $h($ext) ?>">
						<button class="btn btn-xs btn-danger"><?php echo _('Delete extension') ?></button>
					</form>
					<?php endif; ?>
				</td>
			</tr>
		<?php endforeach; if (!$owners): ?>
			<tr><td colspan="4"><?php echo _('None yet') ?></td></tr>
		<?php endif; ?>
		</tbody>
	</table>

<?php else:
	$e = $edit ?: ['id' => 0, 'name' => '', 'description' => '', 'action' => 'ext_status', 'role_id' => '', 'ephemeral' => 1, 'enabled' => 1, 'params' => '{}'];
	$ep = json_decode($e['params'] ?? '{}', true) ?: [];
	$eaction = $e['cmd_action'] ?? $e['action'];
	$erole = $e['cmd_role_id'] ?? $e['role_id'];
	$etext = $e['text'] ?? ($ep['text'] ?? '');
	$epat = $e['allow_pattern'] ?? ($ep['allow_pattern'] ?? '');
	$posted = isset($e['cmd_action']);
	$eeph = $posted ? isset($e['ephemeral']) : (int)$e['ephemeral'];
	$eena = $posted ? isset($e['enabled']) : (int)$e['enabled'];
?>
	<table class="table table-striped">
		<thead><tr><th>/Command</th><th><?php echo _('Action') ?></th><th><?php echo _('Role') ?></th><th><?php echo _('Reply') ?></th><th><?php echo _('Enabled') ?></th><th></th></tr></thead>
		<tbody>
		<?php foreach ($commands as $c): ?>
			<tr>
				<td><code>/<?php echo $h($c['name']) ?></code><br><small><?php echo $h($c['description']) ?></small></td>
				<td><?php echo $h($actions[$c['action']]['label'] ?? $c['action']) ?></td>
				<td><?php echo $c['role_id'] !== '' ? $h($c['role_id']) : '—' ?></td>
				<td><?php echo (int)$c['ephemeral'] ? _('Private') : _('Public') ?></td>
				<td><?php echo (int)$c['enabled'] ? '✔' : '—' ?></td>
				<td style="white-space:nowrap">
					<a class="btn btn-xs btn-default" href="?display=discordprov&view=commands&edit=<?php echo (int)$c['id'] ?>"><?php echo _('Edit') ?></a>
					<form method="post" action="?display=discordprov&view=commands" style="display:inline" onsubmit="return confirm('Delete /<?php echo $h($c['name']) ?>?')">
						<input type="hidden" name="action" value="cmd_delete"><input type="hidden" name="id" value="<?php echo (int)$c['id'] ?>">
						<button class="btn btn-xs btn-danger"><?php echo _('Delete') ?></button>
					</form>
				</td>
			</tr>
		<?php endforeach; ?>
		</tbody>
	</table>

	<h3><?php echo (int)$e['id'] ? _('Edit command') : _('New command') ?></h3>
	<form method="post" action="?display=discordprov&view=commands">
		<input type="hidden" name="action" value="cmd_save">
		<input type="hidden" name="id" value="<?php echo (int)$e['id'] ?>">
		<div class="form-group"><label><?php echo _('Slash command name (a-z 0-9 _ -)') ?></label>
			<input class="form-control" name="name" maxlength="32" value="<?php echo $h($e['name']) ?>"></div>
		<div class="form-group"><label><?php echo _('Description shown in Discord') ?></label>
			<input class="form-control" name="description" maxlength="100" value="<?php echo $h($e['description']) ?>"></div>
		<div class="form-group"><label><?php echo _('Action (what the PBX does)') ?></label>
			<select class="form-control" name="cmd_action">
				<?php foreach ($actions as $k => $a): ?>
				<option value="<?php echo $h($k) ?>" <?php echo $eaction === $k ? 'selected' : '' ?>><?php echo $h($a['label'] . ' — ' . $a['desc']) ?></option>
				<?php endforeach; ?>
			</select></div>
		<div class="form-group"><label><?php echo _('Required Role ID (mandatory for admin actions)') ?></label>
			<input class="form-control" name="cmd_role_id" value="<?php echo $h($erole) ?>"></div>
		<div class="form-group"><label><?php echo _('Reply text (Static text action only)') ?></label>
			<textarea class="form-control" name="text" rows="3"><?php echo $h($etext) ?></textarea></div>
		<div class="form-group"><label><?php echo _('Allowed-number regex (Call forward / Click-to-call; blank = default)') ?></label>
			<input class="form-control" name="allow_pattern" placeholder="^\d{2,6}$" value="<?php echo $h($epat) ?>"></div>
		<div class="checkbox"><label><input type="checkbox" name="ephemeral" <?php echo $eeph ? 'checked' : '' ?>> <?php echo _('Private reply (only the caller sees it)') ?></label></div>
		<div class="checkbox"><label><input type="checkbox" name="enabled" <?php echo $eena ? 'checked' : '' ?>> <?php echo _('Enabled') ?></label></div>
		<p class="help-block"><?php echo _('Saving restarts the bot automatically if it is running.') ?></p>
		<button type="submit" class="btn btn-primary"><?php echo _('Save command') ?></button>
		<?php if ((int)$e['id']): ?><a class="btn btn-default" href="?display=discordprov&view=commands"><?php echo _('Cancel') ?></a><?php endif; ?>
	</form>
<?php endif; ?>
</div>
