# Changelog

## 1.2.0
- Everything is managed from the WebUI: new **Bot** tab with Start/Stop/Restart, live log viewer,
  setup checklist, dependency installer, Discord connection test and invite link.
- Cron watchdog (installed from the GUI) replaces systemd: auto-start after reboot, auto-recovery after crashes.
- Saving settings/commands restarts the bot automatically.
- Provisioned users can be removed from the GUI.
- Release workflow bundles bot dependencies so the module installs from Module Admin without a terminal.

## 1.1.0
- FreePBX 17 only (PHP 8.2+, PJSIP only).
- Custom slash commands mapped to built-in, whitelisted PBX actions (managed in the GUI).
- Live Directory embed in a separate channel, auto-updating.
- Fix: interactions are acknowledged before any `fwconsole` call (avoids Discord's 3s timeout).
- Fix: Discord-user mapping removal on extension delete.

## 1.0.0
- Initial: bot settings, embed + buttons, ephemeral credential delivery.
