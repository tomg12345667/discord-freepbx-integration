<?php
// SPDX-License-Identifier: GPL-3.0-or-later
namespace FreePBX\Console\Command;

use Symfony\Component\Console\Command\Command;
use Symfony\Component\Console\Input\InputArgument;
use Symfony\Component\Console\Input\InputInterface;
use Symfony\Component\Console\Output\OutputInterface;

class Discordprov extends Command {
	protected function configure() {
		$this->setName('discordprov')
			->setDescription('Discord provisioner backend (JSON on the last output line)')
			->addArgument('action', InputArgument::REQUIRED, 'config|commands|directory|run|status|provision|reset|remove|set|watchdog')
			->addArgument('a', InputArgument::OPTIONAL)
			->addArgument('b', InputArgument::OPTIONAL)
			->addArgument('c', InputArgument::OPTIONAL);
	}

	protected function execute(InputInterface $input, OutputInterface $output) {
		$m = \FreePBX::Discordprov();
		$action = $input->getArgument('action');
		$a = (string)$input->getArgument('a');
		$b = (string)$input->getArgument('b');
		$c = (string)$input->getArgument('c');

		$idArg = ($action === 'run') ? $b : $a;
		if (in_array($action, ['status', 'provision', 'reset', 'remove', 'run'], true) && !ctype_digit($idArg)) {
			$output->writeln(json_encode(['ok' => false, 'message' => 'bad_id'])); return 1;
		}

		switch ($action) {
			case 'config':    $r = $m->getSettings(); break;
			case 'commands':  $r = ['ok' => true, 'commands' => $m->commandsForBot()]; break;
			case 'directory': $r = ['ok' => true, 'rows' => $m->directory()]; break;
			case 'run':
				$opts = json_decode($c ?: '{}', true);
				$r = $m->run($a, $b, is_array($opts) ? $opts : []);
				break;
			case 'status':    $r = $m->status($a); break;
			case 'provision': $r = $m->provision($a, $b); break;
			case 'reset':     $r = $m->resetSecret($a); break;
			case 'remove':    $r = $m->remove($a); break;
			case 'set':       $r = ['ok' => $m->setSetting($a, $b)]; break;
			case 'watchdog':  $r = ['ok' => true, 'result' => $m->watchdog()]; break;
			default:          $r = ['ok' => false, 'message' => 'unknown_action'];
		}
		$output->writeln(json_encode($r, JSON_UNESCAPED_UNICODE | JSON_INVALID_UTF8_SUBSTITUTE));
		return 0;
	}
}
