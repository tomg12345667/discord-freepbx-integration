# FreePBX Discord Provisioner

A **FreePBX 17** module + Node.js bot that connects your PBX to Discord — **installed and managed entirely from the FreePBX web UI**.

- **Self-service extensions** – an embed with buttons (Create / Reset Password / Delete). Credentials arrive as **ephemeral** replies only the clicking user can see.
- **Custom slash commands** – map `/commands` to whitelisted PBX actions (status, DND, call forward, click-to-call, directory, static text, PBX status/reload). Add and edit them in the GUI.
- **Live Directory** – an auto-updating embed in any channel with online / offline / DND state and optional owner mentions.
- **Bot tab** – start/stop/restart, live logs, setup checklist, "Test connection", invite link, dependency installer.

## Requirements
FreePBX 17 (Asterisk 21, PHP 8.2) with Node.js 18+ (installed by default with FreePBX 17). Only the **Guilds** intent is used – no privileged intents.

## Install (no terminal)
1. Download `discordprov-<version>.tgz` from the [Releases](../../releases) page (dependencies are bundled).
2. FreePBX: **Admin → Module Admin → Upload Modules**, then either *Upload (from hard disk)* with that file, or *Download (from web)* and paste the release asset URL. Click **Process**, then **Install** and **Apply Config**.
   *(Unsigned third-party module: if Module Admin refuses it, check the module-signature setting under Settings → Advanced Settings.)*
3. Open **Admin → Discord Provisioner**:
   1. Create an application at <https://discord.com/developers/applications>, add a **Bot**, copy the **Token** and the **Application ID**.
   2. **Settings & Directory** tab: enter Client ID, Token, Server ID, panel channel ID and (optionally) the directory channel ID → **Save**.
   3. **Bot** tab: use the **invite link**, click **Test connection** until everything is green, then **Start**.

Enable *Developer Mode* in Discord (Settings → Advanced) to copy server/channel/role IDs.

If you installed from a source checkout (no bundled `node_modules`), press **Install dependencies** on the Bot tab. After a module *upgrade*, check the same button.

## How it works
```
Discord ⇄ bot.js ──execFile──▶ fwconsole discordprov <action> (JSON) ──▶ FreePBX module ──▶ DB / AMI
```
No HTTP API is exposed. The bot is a plain Node process started by the module (as the `asterisk` user); a cron watchdog (`fwconsole discordprov watchdog`, installed on first **Start**) restarts it after crashes and reboots. Stop disables auto-start. If Apache is restarted the bot may be stopped with it; the watchdog brings it back within a minute.

## Commands
Add/edit under **Discord Provisioner → Commands**.

| Action | What it does | Options |
|---|---|---|
| My extension status | Registration, DND, forwarding | – |
| Toggle DND | Writes AstDB `DND/<ext>` | `state`: on/off/toggle |
| Call forward | Writes AstDB `CF/<ext>` | `number` (checked against regex) |
| Click-to-call | AMI Originate: rings your ext, then dials | `number` (checked against regex) |
| Show directory | Same data as Live Directory | – |
| Static text | Fixed reply (`{ext}` placeholder) | – |
| PBX status *(admin)* | Uptime, calls, registrations | role required |
| Reload *(admin)* | `fwconsole reload` in background | role required |

There is deliberately **no** "run arbitrary shell command" action. Admin actions refuse to run unless a required Role ID is set, and roles are enforced in the bot before the backend is called.

## Security notes
- Treat the bot token like a root credential; it is stored in FreePBX's module key-value store in the database.
- Click-to-call and call-forward are toll-fraud surfaces. Keep the internal-only default regexes unless you understand the risk, and gate them with a role.
- Restrict outbound routes / class of service for the provisioned extension range if needed.
- Anyone controlling a Discord account that holds an extension can request a password reset for it.

## Releasing (maintainers)
`git tag v1.2.0 && git push --tags` – the *Release* workflow builds `discordprov-1.2.0.tgz` (with `node_modules`) and attaches it to the GitHub release.

## Development
```bash
php -l Discordprov.class.php && node --check bot/bot.js
```

## License
GPL-3.0-or-later. See `LICENSE`.
