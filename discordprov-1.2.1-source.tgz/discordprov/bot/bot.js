'use strict';
// SPDX-License-Identifier: GPL-3.0-or-later
const { execFile } = require('child_process');
const {
  Client, GatewayIntentBits, EmbedBuilder, ActionRowBuilder, ButtonBuilder,
  ButtonStyle, MessageFlags, Events, REST, Routes,
} = require('discord.js');

const FWCONSOLE = process.env.FWCONSOLE || '/usr/sbin/fwconsole';
const EPHEMERAL = MessageFlags.Ephemeral;
const fs = require('fs');
const sleep = (ms) => new Promise((r) => setTimeout(r, ms));

// Timestamped logging (the GUI tails this file).
for (const lvl of ['log', 'error']) {
  const orig = console[lvl].bind(console);
  console[lvl] = (...a) => orig(new Date().toISOString(), lvl === 'error' ? 'ERROR' : 'INFO ', ...a);
}

// The FreePBX module tracks the process through this pidfile.
const PIDFILE = process.env.DISCORDPROV_PIDFILE;
if (PIDFILE) {
  try { fs.writeFileSync(PIDFILE, String(process.pid)); } catch (e) { console.error('Cannot write pidfile:', e.message); }
}
function shutdown(code) {
  try { if (PIDFILE) fs.unlinkSync(PIDFILE); } catch (_) { /* already gone */ }
  process.exit(code);
}
process.on('SIGTERM', () => { console.log('Stopping (SIGTERM)'); shutdown(0); });
process.on('SIGINT', () => shutdown(0));
process.on('uncaughtException', (e) => { console.error('Uncaught:', e); shutdown(1); });
process.on('unhandledRejection', (e) => { console.error('Unhandled rejection:', e); });

// Config and command list are loaded once at start; saving settings in the GUI
// restarts the bot, so this cache is always current.
// (fwconsole takes ~1s to boot, so it must never run before we ack an interaction.)
const state = { cfg: null, commands: [], dirHash: '' };
const cooldown = new Map();

function fw(...args) {
  return new Promise((resolve, reject) => {
    execFile(FWCONSOLE, ['discordprov', ...args.map(String)], { timeout: 90000 }, (err, stdout) => {
      const last = String(stdout || '').trim().split('\n').pop();
      try { resolve(JSON.parse(last)); } catch (e) { reject(err || new Error('Bad output: ' + last)); }
    });
  });
}

function hasRole(member, roleId) {
  const roles = member?.roles;
  if (!roles) return false;
  return roles.cache ? roles.cache.has(roleId) : Array.isArray(roles) && roles.includes(roleId);
}

function tooFast(userId, ms) {
  const now = Date.now();
  if ((cooldown.get(userId) || 0) > now) return true;
  cooldown.set(userId, now + ms);
  return false;
}

/* ------------------------------------------------------------ provisioning panel */

function panelPayload() {
  const embed = new EmbedBuilder()
    .setTitle('📞 Get a Phone Extension')
    .setDescription('Click a button to manage your personal SIP extension.\nYour credentials are sent **only to you** and are never posted in the channel.')
    .setColor(0x5865f2);
  const row = new ActionRowBuilder().addComponents(
    new ButtonBuilder().setCustomId('dp_create').setLabel('Create Extension').setStyle(ButtonStyle.Success),
    new ButtonBuilder().setCustomId('dp_reset').setLabel('Reset Password').setStyle(ButtonStyle.Primary),
    new ButtonBuilder().setCustomId('dp_delete').setLabel('Delete Extension').setStyle(ButtonStyle.Danger),
  );
  return { embeds: [embed], components: [row] };
}

function credsEmbed(r, title) {
  return new EmbedBuilder().setTitle(title).setColor(0x57f287).addFields(
    { name: 'Extension / Username', value: '`' + r.extension + '`', inline: true },
    { name: 'Password', value: '||`' + r.secret + '`||', inline: true },
    { name: 'Server', value: '`' + r.host + ':' + r.port + '`' },
  ).setFooter({ text: 'Allow ~15s for the PBX to reload. Only you can see this message.' });
}

const ERR = {
  exists: (r) => `You already have extension **${r.extension}**. Use *Reset Password* if you lost the password.`,
  none: () => 'You do not have an extension yet.',
  range_full: () => 'No free extensions are available. Please contact an admin.',
  create_failed: () => 'The PBX could not create the extension. Please contact an admin.',
};

async function handleButton(i) {
  const cfg = state.cfg;
  if (cfg.role_id && !hasRole(i.member, cfg.role_id)) {
    return i.reply({ content: 'You do not have the required role.', flags: EPHEMERAL });
  }
  if (tooFast(i.user.id, 8000)) {
    return i.reply({ content: 'Slow down — try again in a few seconds.', flags: EPHEMERAL });
  }
  if (i.customId === 'dp_delete') {
    const row = new ActionRowBuilder().addComponents(
      new ButtonBuilder().setCustomId('dp_delete_confirm').setLabel('Yes, delete it').setStyle(ButtonStyle.Danger));
    return i.reply({ content: 'This permanently deletes your extension. Sure?', components: [row], flags: EPHEMERAL });
  }

  await i.deferReply({ flags: EPHEMERAL });
  const id = i.user.id;
  let r;
  if (i.customId === 'dp_create') {
    r = await fw('provision', id, i.user.username);
    if (r.error === 'create_failed') console.error('Create failed:', r.detail);
    if (r.ok) return i.editReply({ embeds: [credsEmbed(r, '✅ Extension created')] });
  } else if (i.customId === 'dp_reset') {
    r = await fw('reset', id);
    if (r.ok) return i.editReply({ embeds: [credsEmbed(r, '🔑 Password reset')] });
  } else if (i.customId === 'dp_delete_confirm') {
    r = await fw('remove', id);
    if (r.ok) return i.editReply({ content: `Extension **${r.extension}** deleted.`, components: [] });
  }
  return i.editReply({ content: (ERR[r?.error] || (() => 'Something went wrong.'))(r || {}) });
}

async function ensurePanel(client) {
  const cfg = state.cfg;
  if (!cfg.channel_id) return;
  const channel = await client.channels.fetch(cfg.channel_id);
  if (cfg.panel_message_id) {
    try { await (await channel.messages.fetch(cfg.panel_message_id)).edit(panelPayload()); return; } catch (_) { /* repost */ }
  }
  const sent = await channel.send(panelPayload());
  cfg.panel_message_id = sent.id;
  await fw('set', 'panel_message_id', sent.id);
}

/* --------------------------------------------------------------- slash commands */

async function registerCommands() {
  const { cfg, commands } = state;
  const body = commands.map((c) => ({
    name: c.name,
    description: c.description,
    options: c.options.map((o) => ({
      type: 3, // STRING
      name: o.name, description: o.description, required: !!o.required,
      ...(o.choices && o.choices.length ? { choices: o.choices.map((v) => ({ name: v, value: v })) } : {}),
    })),
  }));
  const rest = new REST({ version: '10' }).setToken(cfg.token);
  const route = cfg.guild_id
    ? Routes.applicationGuildCommands(cfg.client_id, cfg.guild_id)
    : Routes.applicationCommands(cfg.client_id);
  await rest.put(route, { body });
  console.log(`Registered ${body.length} slash command(s)`);
}

async function handleCommand(i) {
  const cmd = state.commands.find((c) => c.name === i.commandName);
  if (!cmd) return i.reply({ content: 'Unknown command.', flags: EPHEMERAL });
  if (cmd.admin && !cmd.role_id) return i.reply({ content: 'This command is disabled until a required role is set.', flags: EPHEMERAL });
  if (cmd.role_id && !hasRole(i.member, cmd.role_id)) return i.reply({ content: 'You do not have the required role.', flags: EPHEMERAL });
  if (tooFast(i.user.id, 3000)) return i.reply({ content: 'Slow down a moment.', flags: EPHEMERAL });

  await i.deferReply(cmd.ephemeral ? { flags: EPHEMERAL } : {});
  const opts = {};
  for (const o of cmd.options) {
    const v = i.options.getString(o.name);
    if (v !== null) opts[o.name] = v;
  }
  const r = await fw('run', cmd.name, i.user.id, JSON.stringify(opts));
  if (!r.ok) return i.editReply({ content: r.message || 'Command failed.' });
  const embed = new EmbedBuilder().setTitle(String(r.title).slice(0, 250))
    .setDescription(r.lines.join('\n').slice(0, 4000)).setColor(0x5865f2);
  return i.editReply({ embeds: [embed] });
}

/* --------------------------------------------------------------- live directory */

function buildDirectoryEmbeds(rows, cfg) {
  const online = rows.filter((r) => r.online).length;
  const dnd = rows.filter((r) => r.dnd).length;
  const lines = rows.map((r) => {
    const icon = r.online === null ? '⚪' : (r.dnd ? '🔴' : (r.online ? '🟢' : '⚫'));
    const who = r.discord_id ? ` — <@${r.discord_id}>` : '';
    return `${icon} **${r.ext}** · ${r.name}${who}`;
  });
  const chunks = []; let cur = '';
  for (const l of lines) {
    if ((cur + l + '\n').length > 3800) { chunks.push(cur); cur = ''; }
    cur += l + '\n';
  }
  if (cur) chunks.push(cur);
  if (!chunks.length) chunks.push('_No extensions to show._');

  const shown = chunks.slice(0, 10);
  const embeds = shown.map((text, idx) => {
    const e = new EmbedBuilder().setColor(0x5865f2).setDescription(text);
    if (idx === 0) e.setTitle('📒 Live Directory').addFields({ name: 'Summary', value: `🟢 ${online} online · 🔴 ${dnd} DND · ${rows.length} total` });
    if (idx === shown.length - 1) e.setFooter({ text: `🟢 online  ⚫ offline  🔴 DND  ⚪ unknown • refreshes every ${cfg.dir_interval}s` });
    return e;
  });
  return embeds;
}

async function updateDirectory(client) {
  const cfg = state.cfg;
  if (!cfg.dir_channel_id) return;
  const r = await fw('directory');
  if (!r.ok) return;
  const hash = JSON.stringify(r.rows);
  if (hash === state.dirHash && cfg.dir_message_id) return; // nothing changed: no API call
  const payload = { embeds: buildDirectoryEmbeds(r.rows, cfg) };
  const channel = await client.channels.fetch(cfg.dir_channel_id);
  let done = false;
  if (cfg.dir_message_id) {
    try { await (await channel.messages.fetch(cfg.dir_message_id)).edit(payload); done = true; } catch (_) { /* repost */ }
  }
  if (!done) {
    const sent = await channel.send(payload);
    cfg.dir_message_id = sent.id;
    await fw('set', 'dir_message_id', sent.id);
  }
  state.dirHash = hash;
}

/* ------------------------------------------------------------------------ main */

async function main() {
  state.cfg = await fw('config');
  while (!state.cfg.token || !state.cfg.client_id) {
    console.log('Token / Client ID not configured yet; waiting...');
    await sleep(15000);
    state.cfg = await fw('config');
  }
  state.commands = (await fw('commands')).commands || [];

  const client = new Client({ intents: [GatewayIntentBits.Guilds] });

  client.once(Events.ClientReady, async (c) => {
    console.log(`Logged in as ${c.user.tag}`);
    try { await registerCommands(); } catch (e) { console.error('Command registration failed:', e.message); }
    try { await ensurePanel(client); } catch (e) { console.error('Panel error:', e.message); }
    const tick = () => updateDirectory(client).catch((e) => console.error('Directory error:', e.message));
    tick();
    setInterval(tick, Math.max(30, parseInt(state.cfg.dir_interval, 10) || 60) * 1000);
  });

  client.on(Events.InteractionCreate, async (i) => {
    try {
      if (i.isButton() && i.customId.startsWith('dp_')) return await handleButton(i);
      if (i.isChatInputCommand()) return await handleCommand(i);
    } catch (e) {
      console.error(e);
      const msg = { content: 'Internal error. Please contact an admin.', flags: EPHEMERAL };
      if (i.deferred || i.replied) i.editReply(msg).catch(() => {}); else i.reply(msg).catch(() => {});
    }
  });

  await client.login(state.cfg.token);
}

main().catch((e) => { console.error(e); shutdown(1); });
